<li><a href="<?php echo the_permalink(); ?>">
	<div class="bghover"></div>
    <?php echo px_post_thumbnail('miniatura'); ?>
	<div class="s2">
		<span class="title"><?php the_title(); ?></span>
        <?php echo app_date(); ?>
	</div>
</a></li>