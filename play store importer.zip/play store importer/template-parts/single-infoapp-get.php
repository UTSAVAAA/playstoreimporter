<?php 
$datos_download = get_datos_download();
$get_download = get_query_var( 'download' );
?>
<div class="right s2">
    <?php px_breadcrumbs(); ?>
    <?php 
    $datos_informacion = get_post_meta($post->ID, 'datos_informacion', true); ?>
    <h1 class="box-title">
        <?php 
        $title = get_the_title(); 
        echo ( str_replace( @$datos_informacion['version'], '', $title ) );  
        ?>
    </h1><?php echo ( !empty(@$datos_informacion['version']) ) ? '<h4 class="version">'.@$datos_informacion['version'].'</h4>' : ''; ?>
    <div class="clear"></div>
    <?php 
    $a = get_option("appyn_download_timer");
    $download_timer = ( isset($a) ) ? get_option( "appyn_download_timer" ) : 5;

    switch( $get_download ) { 	
        case "links":
            echo ads('ads_download_1');
            echo '<div class="bx-download">
                <div class="bxt">'.__( 'Enlaces de descarga', 'appyn' ).'</div>
                <ul '. ( ( $download_timer != "0" ) ? 'class="show_download_links" data-timer="'.$download_timer.'"' : '').' '.( ( $download_timer && !is_amp_px() ) ? 'style="display:none;"': '').'>';
                    foreach( $datos_download['links_options'] as $value => $element ) : 
                        if( !is_string($value) ) :
                        echo '<li><a href="'.px_download_link($element['link']).'" target="_blank"'.((isset($element['follow'])) ? ' rel="follow"' : ' rel="nofollow"').'><i class="fa fa-download"></i> '.$element['texto'].'</a></li>';
                        endif; 
                    endforeach; 
                echo '</ul>';
                if( $download_timer && !is_amp_px() ) {
                     echo '<div class="bxt sdl_text">'.__( 'Esperar', 'appyn' ). ' <span>'.$download_timer.'s</span></div>';
                }
                echo '
            </div>';
            echo px_info_install();
            echo ads('ads_download_2');
        break;

        case "redirect" :
            echo ads('ads_download_1');
                echo '<div class="bx-download">
                <div class="bxt">'.__( 'Será redireccionado en unos segundos...', 'appyn' ).'</div>
                <p>'.__( 'Si la redirección no funciona, haga clic', 'appyn' ).' <a href="'.((strlen($datos_download['direct-link'])>0) ? $datos_download['direct-link'] : 'javascript:alert_download()').'" rel="nofollow">'.__( 'aquí', 'appyn' ).'</a>.</p>
            </div>'; 
            echo px_info_install();
            echo ads('ads_download_2');
        break;

        default :
            echo ads('ads_download_1');
            echo '<div class="bx-download">
                <div class="bxt">'.__( 'Su descarga comenzará en un momento...', 'appyn' ).'</div>
                <p>'.__( 'Si no descarga el archivo, haga clic', 'appyn' ).' <a href="'.((strlen($datos_download['direct-download'])>0) ? $datos_download['direct-download'] : 'javascript:alert_download()').'" rel="nofollow">'.__( 'aquí', 'appyn' ).'</a>.</p>
            </div>';

            echo px_info_install();
            echo ads('ads_download_2');
    }
    ?>
</div>
<div class="left s1">
    <?php echo px_post_thumbnail( 'thumbnail', $post, true ); ?>
    <a href="<?php the_permalink(); ?>" class="downloadAPK"><i class="fa fa-chevron-left" aria-hidden="true"></i> <?php echo __( 'Regresar', 'appyn' ); ?></a>
   
    <?php show_rating(); ?>
    <?php if( !is_amp_px() ) { ?>
    <div class="link-report"><a href="javascript:void(0)"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> <?php echo __( 'Reportar', 'appyn' ); ?></a></div>
    <?php } ?>
</div>