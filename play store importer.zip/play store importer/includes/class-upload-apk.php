<?php

class UploadAPK {
    
    private $urlapk;
    private $post_id;
    private $idps;
    private $update;
    private $datos_download;
    private $uploaddir;
    private $files;
    private $lsa;
    private $da;
    private $op;

    public function __construct( $post_id, $idps, $apk, $update ) {

        $this->urlapk           = $apk;
        $this->post_id          = $post_id;
        $this->idps             = $idps;
        $this->update           = $update;
        $this->datos_download   = array();
        $this->uploaddir        = wp_upload_dir();
        $this->lsa              = px_last_slug_apk();
        $this->da               = "-".( !empty($update) ? date('d-m-Y', $update) : 1);
        $this->op               = 1;

        if( $this->checkAPK_OBB() ) {

            $ext = '.zip';
            $this->temp_file     = tempnam(sys_get_temp_dir(), "zip");

        } else {

            $n = array_keys($this->urlapk);
            $ext = ".apk";
            $this->filetype = $n[0];
			if( $this->filetype == "zip" ) {
				$ext = ".zip";
			}

            $this->direct_url    = $this->urlapk[$n[0]];
            $this->temp_file     = $this->direct_url;

        }
        
        $this->filename     = sanitize_title($this->idps)."{$this->da}{$this->lsa}{$ext}";

        $this->uploadfile   = $this->uploaddir['path'] . '/' . $this->filename;

    }
    
    private function uploadTo() {

        $edcgpss = get_option( 'appyn_edcgp_sapk_server', 1 );

        switch( $edcgpss ) {
            case 1:
                $upload = $this->uploadToWP();
                break;
            case 2:
                $upload = $this->uploadToGDrive();
                unlink( $this->uploadfile );
                break;
            case 3:
                $upload = $this->uploadToDropbox();
                unlink( $this->uploadfile );
                break;
        }

        return $upload;
    }

    private function getFileSizeHeaders( $url = null ) {
        
        if( !$url ) {
            $url = $this->direct_url;
        }

        $headers = get_headers($url, 1);
        $headers = array_change_key_case($headers);
        if( isset($headers['content-length']) ){
            return $headers['content-length'];
        } else {
            return $this->getFileSizeHeaders( $url );
        }
    }
    public function uploadFile() {
        
        if( $this->checkAPK_OBB() ) {

            $this->saveFilesToZip();

            copy( $this->temp_file, $this->uploadfile );

            $upload = $this->uploadTo();

            $this->removeFilesAPKOBB();

        } else {

            $fileSize = $this->getFileSizeHeaders();

            $a = array(
                'filesize'  => ( is_array($fileSize) ) ? end($fileSize) : $fileSize,
                'name'      => $this->uploadfile,
            );

            update_option( 'file_progress', $a );

            $fp = fopen($this->uploadfile, 'w+');
            $ch = curl_init($this->temp_file);
            curl_setopt($ch, CURLOPT_FILE, $fp); 
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_exec($ch);
            curl_close($ch);
            fclose($fp);

            $upload = $this->uploadTo();
        }

        if( isset($upload['error']) ) {
            if( file_exists($this->uploadfile) )
                unlink( $this->uploadfile );
            return array('error' => sprintf( __( 'Error: %s', 'appyn' ), $upload['error']) );
        }
        
        $this->uploadURL = $upload['url'];
        
        $this->updatePostMeta();  		
        
        return $this->uploadURL;
    }

    private function checkAPK_OBB() {
            
        if( count($this->urlapk) != 2 ) return false;

        return ( array_key_exists('apk', $this->urlapk) && array_key_exists('obb', $this->urlapk) ) ? true : false;
    }

    private function checkFileSize() {

        $fgc = file_get_contents($this->uploadfile);
        if( strlen($fgc) == 0 ) {
            unlink($this->uploadfile);
            return array('error' => __( 'El archivo pesa 0KB. No fue descargado ni subido', 'appyn' ) );
        } else {
            return $fgc;
        }

    }

    private function uploadToWP() {

        $attach_id = attachment_url_to_postid( $this->uploaddir['url'] . '/' . $this->filename );
				
        $wp_filetype = wp_check_filetype(basename($this->filename), null );
        $attachment = array(
            'post_mime_type'    => $wp_filetype['type'],
            'post_title'        => $this->filename,
            'post_content'      => '',
            'post_status'       => 'inherit'
        );
        if( $attach_id ) {
            $attach_id = wp_update_attachment_metadata( $attach_id, $attachment );
        } else {
            $attach_id = wp_insert_attachment( $attachment, $this->uploadfile, $this->post_id );
        }

        $fileContent = $this->checkFileSize();

        if( isset($fileContent['error']) ) {
            if( $this->op > 2 ) {
                return $fileContent;
            } else {
                sleep(2000);
                $this->op++;
                return $this->uploadToWP();
            }
        }

        return array( 'url' => $this->uploaddir['url'] . '/' . $this->filename );

    }

    private function uploadToDropbox() {

        if( !get_option('appyn_dropbox_access_token', null) ) {
            return array('error' => __( 'Falta token de acceso', 'appyn' ) );
        }

        $fileContent = $this->checkFileSize();

        if( isset($fileContent['error']) ) {
            if( $this->op > 2 ) {
                return $fileContent;
            } else {
                sleep(2000);
                $this->op++;
                return $this->uploadToDropbox();
            }
        }

        $dropbox = new Dropbox();
        $upload = $dropbox->Upload( $this->uploadfile );

        return $upload;
        
    }

    private function uploadToGDrive() {

        if( !get_option('appyn_gdrive_token', null) ) {
            return array('error' => __( 'No ha realizado la conexión a Google Drive', 'appyn' ) );
        }

        $fileContent = $this->checkFileSize();

        if( isset($fileContent['error']) ) {
            if( $this->op > 2 ) {
                return $fileContent;
            } else {
                sleep(2000);
                $this->op++;
                return $this->uploadToGDrive();
            }
        }

        $gdrive = new GoogleDrive();

        $d = appyn_options( 'gdrive_folder', true );
        $folder_id = ($d) ? $gdrive->createFolder( $d ) : null;

        $upload = $gdrive->insertFileToDrive( $this->uploaddir['url'].'/'.$this->filename, $this->filename, $folder_id, $fileContent );

        return $upload;

    }

    private function updatePostMeta() {

        $this->datos_download['option']     = 'links';
        $this->datos_download[0]['link']    = $this->uploadURL;
        $this->datos_download[0]['texto']   = 'Link';

        if( $this->checkAPK_OBB() ) {
            $this->datos_download['type']   = 'apk_obb';
        } else {
            $this->datos_download['type']   = $this->filetype;
        }

        update_post_meta( $this->post_id, 'datos_download', $this->datos_download );

    }

    private function removeFilesAPKOBB() {

        array_map( 'unlink', $this->files );

    }

    private function saveFilesToZip() {

		$zip = new ZipArchive();
		$zip->open($this->temp_file, ZipArchive::OVERWRITE);
		$apk = $this->urlapk;
			$arr_files = array();
			$fileSize = 0;
			$sum_file_size = 0;
			$i__ = 0;

			foreach ($apk as $type => $f) {
                
				$fname = sanitize_title($this->idps).".{$type}";

                $fileSize = $this->getFileSizeHeaders($f);

                $arr_files['files'][$i__] = array(
                    "name" => $this->uploaddir['path'] . '/' . $fname,
                    "size" => ( is_array($fileSize) ) ? end($fileSize) : $fileSize
                );
                $sum_file_size += ( is_array($fileSize) ) ? end($fileSize) : $fileSize;
				$i__++;
			}
			$arr_files['totalsize'] = $sum_file_size;

			$this->files = array();

            update_option( 'file_progress', $arr_files );

			foreach ($apk as $type => $f) {
				$fname = sanitize_title($this->idps).".{$type}";
				$this->files[] = $this->uploaddir['path'] . '/' . $fname;
				copy($f, $this->uploaddir['path'] . '/' . $fname);
				$zip->addFile($this->uploaddir['path'] . '/' . $fname, $fname);
			}

		$zip->close();
		fclose($this->temp_file);

        return $arr_files;

    }

}