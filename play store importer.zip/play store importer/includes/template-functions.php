<?php
function count_rating($post_id){
	global $wpdb;
	$array = array();
	$rating_count = ( get_post_meta( $post_id, 'new_rating_count', true ) ) ? get_post_meta( $post_id, 'new_rating_count', true ) : 0;
	$users = ( get_post_meta( $post_id, 'new_rating_users', true ) ) ? get_post_meta( $post_id, 'new_rating_users', true ) : 0;
	$average = ( get_post_meta( $post_id, 'new_rating_average', true ) ) ? get_post_meta( $post_id, 'new_rating_average', true ) : 0;

	$array['average'] = $average;
	$array['users'] =  $users;
	$array['count'] =  $rating_count;
	
	return $array;	
}

function user_no_voted(){
	global $wpdb, $post;
	$ip = $_SERVER['REMOTE_ADDR'];
	if( !isset($_COOKIE['nw_rating']) ) 
		return true;

	$nr = explode(",",$_COOKIE['nw_rating']);
	if( !in_array($post->ID, $nr) ) {
		return true;
	}
}

function show_rating($calificar = 1){
	global $post;
	$count_rating = count_rating($post->ID); ?>
		<div class="box-rating<?php if(wp_is_mobile()) echo " movil"; if(!user_no_voted() || $calificar == 0) echo " voted";  ?>" data-post-id="<?php echo $post->ID; ?>">
		<span class="rating">
			<?php
			if($calificar == 1){ ?>
			<span class="ratings-click" title="<?php echo ( !user_no_voted() ) ? __( 'Calificación', 'appyn' ).": ".$count_rating['average']." ".__( 'estrellas', 'appyn' ): ''; ?>">
				<span class="rating-click r1" data-count="1"></span>
				<span class="rating-click r2" data-count="2"></span>
				<span class="rating-click r3" data-count="3"></span>
				<span class="rating-click r4" data-count="4"></span>
				<span class="rating-click r5" data-count="5"></span>
				</span>
			<?php } ?><span class="stars" style="width:<?php echo $count_rating['average'] * 10 * 2; ?>%"></span></span> 
			<?php
			if($calificar == 1){ ?><span class="text-rating"><b><?php echo $count_rating['average']; ?></b>/5</span>
				<span class="rating-text"><?php 
				if($count_rating['users'] > 0) {
					echo __( 'Votos', 'appyn' ).': '.number_format($count_rating['users'], 0, ',', ',');
				} else {
					echo __( 'No hay votos', 'appyn' ); 
				} ?></span>
			<?php } ?>
		</div>	
<?php	
}

function get_image_id($image_url) {
	global $wpdb;
	$attachment = $wpdb->get_col("SELECT ID FROM $wpdb->posts WHERE guid LIKE '%$image_url%'"); 
	return $attachment[0]; 
}

function ads($ads){
	global $wp_query;
	
	if( is_404() ) return;

	if( isset($wp_query->queried_object->count) ) 
		if( $wp_query->queried_object->count == 0) return;

	$ads_output = '';
	$ads_pc = get_option( 'appyn_'.$ads );
	$ads_movil = get_option( 'appyn_'.$ads.'_movil' );
	$ads_amp = get_option( 'appyn_'.$ads.'_amp' );
	$ads_h = '<aside class="ads '.$ads.'">';
	$ads_h .= appyn_options('ads_text_above') ? '<small>'.appyn_options('ads_text_above').'</small>': '';
	if( is_amp_px() ) {
		if( !empty($ads_amp) ) {
			$ads_output = $ads_h.$ads_amp;
			$ads_output .= '</aside>';
		}
	} else {
		if( !empty($ads_pc) && !wp_is_mobile()) { 
			$ads_output = $ads_h.$ads_pc;
			$ads_output .= '</aside>';
		}
		elseif(!empty($ads_movil) && wp_is_mobile()) {
			$ads_output = $ads_h.$ads_movil;
			$ads_output .= '</aside>';
		}
	}
	return stripslashes($ads_output);
}

function array_multi_filter_download_empty($var) {
	if( is_array($var) ) {
		$var = @array_filter($var);
		return ($var & !empty($var));
	} else {
		return $var;
	}
}

function catch_that_image() {
	global $post, $posts;
	$first_img = '';
	ob_start();
	ob_end_clean();
	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
	$first_img = $matches[1][0];
	return $first_img;
}

function excerpt($limit){
	$excerpt = explode(' ', get_the_excerpt(), $limit);
    if(count($excerpt)>=$limit) {
		array_pop($excerpt);
		$excerpt = implode(" ",$excerpt).'...';
	} else {
		$excerpt = implode(" ",$excerpt);
	} 
	$excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
	return $excerpt;
}

function getPostViews($postID) {
	global $wpdb;
	$px_views = ( get_post_meta( $postID, 'px_views', true ) ? get_post_meta( $postID, 'px_views', true ) : 0 );
	return $px_views;	
}

function setPostViews($postID) {
	global $wpdb;
	$px_views = ( get_post_meta( $postID, 'px_views', true ) ? get_post_meta( $postID, 'px_views', true ) : 0 );
	update_post_meta( $postID, 'px_views', ($px_views + 1) );
}

function px_comment_nav() {
	if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
	?>
	<nav class="navigation comment-navigation" role="navigation">
		<h2 class="screen-reader-text"><?php echo __( 'Navegación de comentarios', 'appyn' ); ?></h2>
		<div class="nav-links">
			<?php
				if ( $prev_link = get_previous_comments_link( __( 'Comentarios antiguos', 'appyn' ) ) ) :
					printf( '<div class="nav-previous">%s</div>', $prev_link );
				endif;

				if ( $next_link = get_next_comments_link( __( 'Comentarios más nuevos', 'appyn' ) ) ) :
					printf( '<div class="nav-next">%s</div>', $next_link );
				endif;
			?>
		</div>
	</nav>
	<?php
	endif;
}

function px_social($social) {
	if( $social == "facebook" ){
		$option = get_option( 'appyn_social_facebook' );
	}
	elseif( $social == "twitter" ){
		$option = get_option( 'appyn_social_twitter' );		
	}
	elseif( $social == "instagram" ){
		$option = get_option( 'appyn_social_instagram' );		
	}
	elseif( $social == "youtube" ){
		$option = get_option( 'appyn_social_youtube' );		
	}
	elseif( $social == "pinterest" ){
		$option = get_option( 'appyn_social_pinterest' );		
	}
	return $option;
}

function options_report($i) {
	if( $i == 1 ) {
		return __("No funcionan los enlaces de descarga", "appyn");
	} elseif( $i == 2 ) {
		return __("Hay una nueva versión", "appyn");
 	} else {
		return __("Otros", "appyn");
	}
}

function px_the_content() {
	global $post;
	$content = get_the_content();
	$content = apply_filters('the_content', $content);
	$content = str_replace(']]>', ']]&gt;', $content);
	echo px_content_filter($content);
}

function px_noimage($bg = false) {
	$noimage = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKoAAACqBAMAAADPWMmxAAAAElBMVEXu7u7////09PT7+/v39/fx8fFOJAxSAAABPklEQVRo3u3YQW6DMBCFYYLjAzxM9iRK9tA2e2h6ACP1/mcpFDlQNVTQGdpEvO8Av62RDYKIiIiIiIiIiIj+THyY4TS1usEMjlVW/7+aTLourK60ai+v+lVbAGf1ao2G164WaOTKVYtWolyN0UqVq1u03F3u9enmXHeyqkW2wBkw32Zh2pSXVffhxPcU7lYRZtizx1Mkq8ZoeO1nlkHjrF2t0HBeuYpPedS5eJXq9ss732KnUq3RycOQM41qgY4LayQKVYsgD2uU8qpBkIaz6+TVGldlWCMXVwsMN1uh5bywGmMgs+jshFWDgcRc+7LqHkNVPwxRtcBtpaS6xQgnqW4w5iyoVhjj/BJVJItUkS1STRepIl+k6n5bfX/7SfYQ3zArqaaHCY738deB1XVXzfMMLxERERERERERET24D8nRkAcrLOazAAAAAElFTkSuQmCC";
	$color_theme = get_option( 'appyn_color_theme' );
	$color_theme_principal = get_option( 'appyn_color_theme_principal' );
	if( is_dark_theme_active() ) {
		$noimage = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKoAAACqBAMAAADPWMmxAAAAG1BMVEUUHClHTVcNFB8mLDgdIy5CSVMRGCI0O0Q8QkuIZNk8AAABTUlEQVRo3u3YQWqDQBTG8UDpAT6UmG0TGd1qAu02pvQCPYH2BErpPll47pqMBiFaYt8TIn6/A/xnGJ+CsyAiIiIiIiIiool7xgCfo1QdVlkdUnXXd/BZnWnVvO70qyYHSvVqikqmXc1ROSlXDc5c1aotAY5ydYMz7yH3+t15rktZ1SDpmoFCVg1uziIEsBLO6x7Ibjf7I3y3jvYM28zhYy2r+qhk2t+sEJVSuxrBPhvdKi5OdeUtU6lucOE1s7tUqaawinp2kWhUc1hes4arUDVoFM0asbwaoOHUDXjyaoqruJ5dFOJqjvZmI9jhFVZ9tCQG1lJYDdHiBte+rLpHW4SaI6se0S2WVDfo4UmqL+hTCqoR+qyyMapwR6kiGaXqjFJFMUrV+2/1a/uXZBL/MDOpOu93ODzGrQOr864+bQfYLYiIiIiIiIiIaOJ+Af2TM1DDPhQQAAAAAElFTkSuQmCC";
	}
	
	if( $bg ) return $noimage;

	if( is_amp_px() ) {
		return '<amp-img src="'.$noimage.'" class="image-single" layout="responsive" width="150" height="150" alt="No image"></amp-img>';
	} else {
		if( appyn_options( 'lazy_loading') ) {
			return '<img data-src="'.$noimage.'" src="" width="150" height="150" alt="No image" class="lazyload">';
		} else {
			return '<img src="'.$noimage.'" width="150" height="150" alt="No image">';
		}
	}
}

function count_reports() {
	global $wpdb;
	$wpdb->get_results( "SELECT meta_value, post_id FROM ".$wpdb->prefix."postmeta WHERE meta_key = 'px_app_report' ORDER BY meta_id DESC" );
	return $wpdb->num_rows;
}

function appyn_options($option, $empty = false) {

	if( !empty(get_option('appyn_'.$option) ) ) {
		return get_option('appyn_'.$option);
	} else {
		return ( $empty ) ?  '' : '0';
	}
}

function get_datos_download(){
	global $post;
	$datos_download = get_post_meta($post->ID, 'datos_download', true); 
	$n = array();
	if( !is_array($datos_download) ) return;
	foreach( $datos_download as $k => $v ) {
		if( !is_string($k) ) {
			if( !empty($v['link']) ) {
				$n[] = $v;
				unset($datos_download[$k]);
			}
		}
	}
	$datos_download['links_options'] = $n;

	if( !empty($datos_download) ) { 
		$datos_download = array_filter($datos_download, 'array_multi_filter_download_empty');
	}
	return $datos_download;
}

function get_datos_info($key, $key_ = false){
	global $post;
	$di = get_post_meta($post->ID, 'datos_informacion', true); 
	if( !empty($di) ) { 
		$di = array_filter($di, 'array_multi_filter_download_empty');

		if( $key_ ) 
			return (isset($di[$key][$key_])) ? $di[$key][$key_] : '';
		else 
			return (isset($di[$key])) ? $di[$key] : '';
	}
}

function category_parents(){
	global $post;
    $category = get_the_category();
    $catid = $category[0]->cat_ID;
    $separador = " / ";
    $category_parents = get_category_parents( $catid, TRUE, "$separador", FALSE );
	$category_parents = explode($separador, $category_parents);
	if( is_array($category_parents) ) {
		$category_parents = array_filter($category_parents, 'array_multi_filter_download_empty');
		return $category_parents;
	}
}

function go_curl($url) {	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
	curl_setopt($ch, CURLOPT_REFERER, get_site_url());
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       
	$content = curl_exec($ch);
	curl_close($ch);
	
	return $content;
}

function is_amp_px() {
	global $wp;
	$amp = appyn_options( 'amp' );
	$current_url = home_url(add_query_arg(array($_GET), $wp->request));
	if( $amp ) {
		return ( strpos($current_url, '?amp') !== false ) ? true : false;
	}
}

function amp_comment_form(){
	global $post;
	echo '<p><a href="'.esc_url( remove_query_arg( 'amp', get_the_permalink( $post->ID ) ) ).'#comment">'.__( 'Deja un comentario', 'appyn' ).'</a></p>';
}

function px_amp_logo($logo_url) {
	return '<amp-img src="'.$logo_url.'" alt="'.get_bloginfo('title').'" layout="fixed-height" height="40"></amp-img>';
}

function appyn_comment($comment, $args, $depth) {
    if ( 'div' === $args['style'] ) {
        $tag       = 'div';
        $add_below = 'comment';
    } else {
        $tag       = 'li';
        $add_below = 'div-comment';
    }?>
    <<?php echo $tag; ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?> id="comment-<?php comment_ID() ?>"><?php 
    if ( 'div' != $args['style'] ) { ?>
        <div id="div-comment-<?php comment_ID() ?>" class="comment-body"><?php
    } ?>
        <div class="comment-author vcard"><?php 
            if ( $args['avatar_size'] != 0 ) {
				if( is_amp_px() ) {
               		echo '<amp-img src="'.get_avatar_url( $comment, $args['avatar_size'] ).'" width="56" height="56"></amp-img>';
				} else {
               		echo get_avatar( $comment, $args['avatar_size'] );
				} 
            } 
            printf( '<cite class="fn">%s</cite> <span class="says">'.__( 'dice', 'appyn' ).':</span>', get_comment_author_link() ); ?>
        </div><?php 
        if ( $comment->comment_approved == '0' ) { ?>
            <em class="comment-awaiting-moderation"><?php echo __( 'Tu comentario está en espera de aprobación.', 'appyn' ); ?></em><br/><?php 
        } ?>
        <div class="comment-meta commentmetadata">
            <a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>"><?php
                printf( 
                    __( '%1$s a las %2$s', 'appyn' ), 
                    get_comment_date(),  
                    get_comment_time() 
                ); ?>
            </a><?php 
            edit_comment_link( __( '(Editar)', 'appyn' ), '  ', '' ); ?>
        </div>

        <?php comment_text(); ?>

        <div class="reply"><?php 
                comment_reply_link( 
                    array_merge( 
                        $args, 
                        array( 
                            'add_below' => $add_below, 
                            'depth'     => $depth, 
                            'max_depth' => $args['max_depth'] 
                        ) 
                    ) 
                ); ?>
        </div><?php 
    if ( 'div' != $args['style'] ) : ?>
        </div><?php 
    endif;
}

function px_post_thumbnail( $size = 'thumbnail', $post = NULL, $bg = false ) {
	if( !$post ) {
		global $post;
	}
	$add_class = '';
	if( appyn_options( 'lazy_loading') && !is_amp_px() ) {
		$add_class = ' bi_ll';
	}
	$output = '<div class="bloque-imagen'.$add_class.(($size == 'miniatura') ? ' w75' : '').'">';
	$output .= px_post_status();
	$image = ($bg) ? px_noimage(true) : px_noimage();
    if( has_post_thumbnail() ) {
        $featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );
        if  ( ! empty( $featured_image_url ) ) {
			$gtpt = get_the_post_thumbnail($post->ID, $size);
			if( $bg ) {
				$gtpt = get_the_post_thumbnail_url($post->ID, $size);
			}
       		if  ( ! empty( $gtpt ) ) {
				$image = $gtpt;
			}
        } 
	}
	if( $bg ) {
		if( is_amp_px() ) {
			$output .= '<div class="image-single" style="background-image:url('.$image.');"></div>';
		} else {
			if( appyn_options( 'lazy_loading') ) {
				$output .= '<div class="image-single lazyload" data-bgsrc="'.$image.'""></div>';
			} else {
				$output .= '<div class="image-single" style="background-image:url('.$image.');"></div>';
			}
		}
	} else {
		$output .= $image;
	}
	$output .= '</div>';
	return $output;
}

function px_content_filter($content){
	if( is_amp_px() ) {
		// Imágenes
		$re = '/<img(.*?)src=(\'|\")(.*?)(\'|\")(.*?)(\/)?>/m';
        preg_match_all($re, $content, $matches, PREG_SET_ORDER, 0);
        $images = array();
        foreach( $matches as $m ) {
            if( strpos($m[0], 'width=') === false ) {
				ob_start(); 
				$data = getimagesize(str_replace(get_site_url(), ABSPATH, $m[3]));
				$data = ob_get_clean(); 
				list($width, $height) = $data;
				if( !empty($width) ) {
					$subst = '<amp-img$1src=$2$3$4$5 layout="intrinsic" width="'.$width.'" height="'.$height.'"></amp-img>';
				} else { 
					list($width, $height) = getimagesize($m[3]);
					$subst = '<amp-img$1src=$2$3$4$5 layout="intrinsic" width="'.$width.'" height="'.$height.'"></amp-img>';
				}
                $images[$m[0]] = preg_replace($re, $subst, $m[0]);
            } else {
				ob_start(); 
				$data = getimagesize(str_replace(get_site_url(), ABSPATH, $m[3]));
				$data = ob_get_clean(); 
				list($width, $height) = $data;
				if( !empty($width) ) {
					$subst = '<amp-img$1src=$2$3$4$5 layout="intrinsic" style="max-width:'.$width.'px"></amp-img>';
					$images[$m[0]] = preg_replace($re, $subst, $m[0]);
				} else {
					list($width, $height) = getimagesize($m[3]);
					$subst = '<amp-img$1src=$2$3$4$5 layout="intrinsic" style="max-width:'.$width.'px"></amp-img>';
					$images[$m[0]] = preg_replace($re, $subst, $m[0]);
				}
            }
        }
        $content = strtr($content, $images);

		$videos = array();
		$re = '/<iframe.+?src="https?:\/\/www\.youtube\.com\/embed\/([a-zA-Z0-9_-]{11})"[^>]+?><\/iframe>/ms';
		preg_match_all($re, $content, $matches, PREG_SET_ORDER, 0);
		foreach( $matches as $v ) {
			$videos[$v[0]] = '<amp-youtube data-videoid="'.$v[1].'" layout="responsive" width="480" height="270"></amp-youtube>';
		}
		$content = strtr($content, $videos);

		$re = '/<script(.*?)<\/script>/ms';

		$content = preg_replace($re, '', $content);

		return $content;
	}
	return $content;
}

function lang_object_ids($object_id, $type) {
    $current_language= apply_filters( 'wpml_current_language', NULL );
    if( is_array( $object_id ) ){
        $translated_object_ids = array();
        foreach ( $object_id as $id ) {
            $translated_object_ids[] = apply_filters( 'wpml_object_id', $id, $type, true, $current_language );
        }
        return $translated_object_ids;
    } else {
		return apply_filters( 'wpml_object_id', $object_id, $type, true, $current_language );
	}
}

function app_developer(){
	global $post;
	$datos_informacion = get_post_meta($post->ID, 'datos_informacion', true);
	$output = '<span class="developer">';
	if( isset($datos_informacion['desarrollador'] ) ) {
		$output .= $datos_informacion['desarrollador'];
	} else {
		$dev_terms = wp_get_post_terms( $post->ID, 'dev', array('fields' => 'all'));
		if( !empty($dev_terms) ) {
			$output .= $dev_terms[0]->name;
		}
	}
	$output .= '</span>';
	return $output;
}

function app_date(){
	global $post;
	$appyn_post_date = appyn_options( 'post_date' );
	$appyn_post_date_type = appyn_options( 'post_date_type' );
	if( !$appyn_post_date ) return; 

	$date = get_the_date( get_option( 'date_format' ), $post->ID);
	if( $appyn_post_date_type == 1 ) {
		$date_change = array(
			'enero' => '01',
			'febrero' => '02',
			'marzo' => '03',
			'abril' => '04',
			'mayo' => '05',
			'junio' => '06',
			'julio' => '07',
			'agosto' => '08',
			'setiembre' => '09',
			'octubre' => '10',
			'noviembre' => '11',
			'diciembre' => '12',
			' de ' => '-',
		);
		$inf = get_post_meta( $post->ID, 'datos_informacion', true );
		if( !empty($inf['fecha_actualizacion']) ) {
			$date = date_i18n( get_option( 'date_format' ), strtotime(strtr($inf['fecha_actualizacion'], $date_change)));
		}
	}
	$output = '<span class="app-date">'.$date.'</span>';
	return $output;
}

function cover_header() {
	$arrayimgs = array();
	for($n=1;$n<=5;$n++){
		$option = appyn_options( 'image_header'.$n);
		if( !empty($option) )
			$arrayimgs[] = appyn_options( 'image_header'.$n);	
	}

	if( empty($arrayimgs) ) return;
	
	if( appyn_options( 'lazy_loading') ) {
		return '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAI4AAACNAQMAAABbp9DlAAAAA1BMVEUUHCkYkPNHAAAAGUlEQVRIx+3BMQEAAADCIPunNsU+YAAA0DsKdwABBBTMnAAAAABJRU5ErkJggg==" data-src="'.$arrayimgs[rand(0,(count($arrayimgs) - 1))].'" alt="Portada" class="lazyload" loading="lazy">';
	} else {
		return '<img src="'.$arrayimgs[rand(0,(count($arrayimgs) - 1))].'" alt="Portada">';
	}
}

function get_remote_html( $url ) {
	$response = wp_remote_get( $url );
	if ( is_wp_error( $response ) ) {
		return;
	}
	$html = wp_remote_retrieve_body( $response );
	if ( is_wp_error( $html ) ) {
		return;
	}
	return $html;
}

function activate_versions_boxes($caja) {
	$cvn = get_option( 'appyn_versiones_no_cajas', array(1) );

	if( !in_array( $caja, $cvn ) ) {
		return true; 
	}
}

function activate_internal_page_boxes($caja) {
	$cvn = get_option( 'appyn_pagina_interna_no_cajas', array(1) );

	if( !in_array( $caja, $cvn ) ) {
		return true; 
	}
}

function is_download_links_normal() {
	$option_download = get_option( 'appyn_download_links' );
	if( $option_download == 0 )
		return true;
}

function link_button_download_apk() {
	global $post;

	$datos_download = get_datos_download();
	$option_download = get_option( 'appyn_download_links' );

	if( empty($datos_download['option']) ) { 

		if( !empty($datos_download['links_options'][0]) ) { 
			return ( ( $option_download == 1 ) ? add_query_arg('download', 'links', esc_url(remove_query_arg('amp')) ) : '#download');
		}
		
	} elseif( $datos_download['option'] == "links" && count($datos_download) > 1 ){

		if( !empty($datos_download['links_options'][0]) ) { 
			return ( ( $option_download == 1) ? add_query_arg('download', 'links', esc_url(remove_query_arg('amp'))) : '#download' );
		}

	} 
	elseif( $datos_download['option'] == "direct-link" ){
		
		if( !empty($datos_download['direct-link']) ) { 
			return ( ( $option_download == 1 ) ? add_query_arg('download', 'redirect', esc_url(remove_query_arg('amp'))) : px_download_link($datos_download['direct-link']) );
		}

	} 
	elseif( $datos_download['option'] == "direct-download" ){

		if( !empty($datos_download['direct-download']) ) { 
			return ( ( $option_download == 1 ) ? add_query_arg('download', 'true', esc_url(remove_query_arg('amp'))) : px_download_link($datos_download['direct-download']) ); 
		}

	}
}

function px_data_structure() {
	global $post;
	if( is_singular('post') ) {
		$rating = count_rating($post->ID);
		if( $rating['average'] > 0 ) {
			$datos_informacion = get_post_meta($post->ID, 'datos_informacion', true); 
			$price = ( (!isset($datos_informacion['offer']['price']) || @$datos_informacion['offer']['price'] == "gratis") ? '0' : $datos_informacion['offer']['price'] );
			$currency = 0;

			if( $price == "pago" ) {
				$price = @$datos_informacion['offer']['amount'];
				$currency = @$datos_informacion['offer']['currency'];
			}

			$os = (empty(@$datos_informacion['os'])) ? 'ANDROID' : @$datos_informacion['os'];

			$cat = ( !isset($datos_informacion['categoria_app']) ? 'GameApplication' : $datos_informacion['categoria_app'] );

			$code = '<script type="application/ld+json">
				{
				"@context": "http://schema.org",
				"@type": "SoftwareApplication",
				"name": "'.get_the_title().'",
				"operatingSystem": "'.$os.'",
				"applicationCategory": "http://schema.org/'.$cat.'",
				"aggregateRating": {
					"@type": "AggregateRating",
					"ratingValue": "'.$rating['average'].'",
					"ratingCount": "'.str_replace(',','',$rating['users']).'"
				},
				"offers": {
					"@type": "Offer",
					"price": "'.$price.'",
					"priceCurrency": "'.$currency.'"
				}
				}
				</script>';
				echo str_replace(array("\n", "\t"), '', $code);
		}
		

		$cat = get_the_category();
		if( !empty($cat[0]) ) {
			$pos = 1;
			echo '<script type="application/ld+json">
					{
					"@context": "https://schema.org",
					"@type": "BreadcrumbList",
					"itemListElement": [';
			if( $cat[0]->category_parent ) {
				$cat_parent = get_term_by('id', $cat[0]->category_parent, 'category');
			echo '{
					"@type": "ListItem",
					"position": '.$pos++.',
					"name": "'.$cat_parent->name.'",
					"item": "'.get_term_link($cat[0]->category_parent).'"
				},';
			}
			echo '{
					"@type": "ListItem",
					"position": '.$pos++.',
					"name": "'.$cat[0]->name.'",
					"item": "'.get_term_link($cat[0]->term_id).'"
				}';

			echo ']
				}
			</script>';
		}
	}
}

function get_store_app() {
	global $post;
	$datos_informacion = get_post_meta($post->ID, 'datos_informacion', true);
	$output = '';
	if( !is_array($datos_informacion) ) return;

	if( strpos($datos_informacion['consiguelo'], 'microsoft.com') !== false ) {
		if( is_amp_px() ) {
			$output = '<amp-img src="'.get_template_directory_uri().'/images/windows.png" width="120" height="38" alt="Windows Store"></amp-img>'; 
		} else {
			$output = '<img src="'.get_template_directory_uri().'/images/windows.png" alt="Windows Store">';
		}
	}
	elseif( strpos($datos_informacion['consiguelo'], 'apps.apple.com') !== false ) {
		if( is_amp_px() ) {
			$output = '<amp-img src="'.get_template_directory_uri().'/images/appstore.png" width="120" height="36" alt="App Store"></amp-img>'; 
		} else {
			$output = '<img src="'.get_template_directory_uri().'/images/appstore.png" alt="App Store">';
		}
	} else {
		if( is_amp_px() ) {
			$output = '<amp-img src="'.get_template_directory_uri().'/images/googleplay.png" width="120" height="27" alt="Google Play"></amp-img>'; 
		} else {
			$output = '<img src="'.get_template_directory_uri().'/images/googleplay.png" width="120" height="27" alt="Google Play">';
		}
	}
	return $output;
}

function px_pay_app() {
	global $post;
	$datos_informacion = get_post_meta($post->ID, 'datos_informacion', true);

	if( !isset($datos_informacion['offer']['price']) ) return;

	if( $datos_informacion['offer']['price'] != "pago" ) return;

	if( empty($datos_informacion['offer']['amount']) ) {	
		return '<ul class="amount-app">
			<li>'.__( 'De pago', 'appyn' ).'</li>
		</ul>';
	} else {
		return '<ul class="amount-app">
	<li>'.$datos_informacion['offer']['amount'].' '.$datos_informacion['offer']['currency'].'</li>
</ul>';
	}
}

function px_check_apk_obb($data) {

	if( count($data) != 2 ) return false;

	return ( array_key_exists('apk', $data) && array_key_exists('obb', $data) ) ? true : false;
}

function get_http_response_code($url) {
	$args = array(
        'sslverify'   => false,
    );

    $request = wp_remote_get( $url, $args );

    if ( wp_remote_retrieve_response_code( $request ) == 200 ) {
		return true;
	}
}

function slugify($text) {
	global $url_app;
	$re = '/[^A-Za-z0-9-]+/m';
	preg_match_all($re, $text, $matches, PREG_SET_ORDER, 0);
	if( count($matches) > 0 ) {
		$re = '/\?id=com\.([a-zA-Z\.]+)/ms';
		preg_match_all($re, $url_app, $matches, PREG_SET_ORDER, 0);
		$nombre = $matches[0][1];
	} else {
		$nombre = $text;
	}
  	return $nombre;
}

function px_upload_image() {
    global $datos, $post_id, $url_app;
	$image = $datos['imagecover'];
	$nombre = slugify(sanitize_title(strip_tags(wp_staticize_emoji($datos['nombre']))));
	
	$uploaddir = wp_upload_dir();
	$filename = "{$nombre}.png";
	$uploadfile = $uploaddir['path'] . '/' . $filename;

	if( !file_exists($uploadfile) ) {
		$wp_filetype = wp_check_filetype(basename($filename), null );
		$attachment = array(
			'post_mime_type' => $wp_filetype['type'],
			'post_title' => $filename,
			'post_content' => '',
			'post_status' => 'inherit'
		);

		$attach_id = wp_insert_attachment( $attachment, $uploadfile );
	} else {
		$attach_id = attachment_url_to_postid($uploaddir['url'].'/'.$filename);
	}
	copy($image, $uploadfile);

	require_once(ABSPATH . 'wp-admin/includes/image.php');
	$attach_data = wp_generate_attachment_metadata( $attach_id, $uploadfile );
	wp_update_attachment_metadata( $attach_id, $attach_data );

	set_post_thumbnail( $post_id, $attach_id );
}

function versions_permalink() {
	global $post;

	$permalink = ( !$post->post_parent ) ? get_permalink() : get_permalink( $post->post_parent );
	if( is_amp_px() ) {
		return esc_url( rtrim(remove_query_arg('amp', $permalink), '/')."/versions/?amp=1" );
	} else {
		return esc_url( rtrim($permalink, '/')."/versions/" );
	}
}

function px_nav_menu( $type = '' ) {

	$c = '';
	$button_light_dark = '';

	$option_color_theme_user_select = appyn_options( 'color_theme_user_select' );
	if( $option_color_theme_user_select == 1 ) {
		if( is_dark_theme_active() )
			$c = ' class="active"';
			
		$button_light_dark = '<div id="button_light_dark"'.$c.'><span class="bld_ico"></span><span class="bld_"></div>';
	}

	$args = array(
		'show_home' => true, 
	);
	if( $type == "mobile" ) {

		$args['theme_location'] = 'menu-mobile';
		$args['container'] = '';
		$args['items_wrap'] = '<ul id="%1$s" class="%2$s">%3$s <li>'.px_header_social().'</li></ul>';

	} else {

		$args['theme_location'] = 'menu';
		$args['container'] = 'nav';
		$args['items_wrap'] = '<div class="menu-open"><i class="fa fa-bars" aria-hidden="true"></i></div><ul id="%1$s" class="%2$s">%3$s</ul>'.$button_light_dark.'';

	}
	
	wp_nav_menu( $args );
}

function px_blog_postmeta() {
	global $post;
	?>
	<div class="px-postmeta">
		<span><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php the_time(get_option( 'date_format' )); ?></span> <span><i class="fa fa-user" aria-hidden="true"></i> <?php the_author_link(); ?></span>
		<?php 
		if( get_the_term_list( $post->ID, 'cblog' ) ) {
		?>
		<span><i class="fa fa-folder" aria-hidden="true"></i> <?php echo get_the_term_list( $post->ID, 'cblog', '', ', ' ); ?></span> 
		<?php } ?>
		<span><i class="fa fa-comments-o" aria-hidden="true"></i> <?php comments_number(); ?></span>
	</div>
	<?php
}

function px_post_status() {
	global $post;
	$inf = get_post_meta( $post->ID, 'datos_informacion', true );
	if( isset($inf['app_status']) ) {
		if( $inf['app_status'] == 'new' ) {
			if( date('U') <= date('U', strtotime($post->post_date. '+ 2 weeks')) )
				return '<div class="bloque-status bs-new">'.__( 'Nuevo', 'appyn' ).'</div>';
		}
		elseif( $inf['app_status'] == 'updated' ) {
			if( date('U') <= date('U', strtotime($post->post_date. '+ 2 weeks')) )
			return '<div class="bloque-status bs-update">'.__( 'Actualizado', 'appyn' ).'</div>';
		}
	} 
}

function px_info_install() {
	global $post;

	$d = get_datos_download();
	$a = str_replace('[Title]', $post->post_title, appyn_options( 'apps_info_download_apk', true ));
	$b = str_replace('[Title]', $post->post_title, appyn_options( 'apps_info_download_zip', true ));

	if( !empty($a) || !empty($b) ) {

		if( isset($d['type']) ) {
			$output = '<div class="bx-info-install">';

			if( $d['type'] == 'apk' )
				$output .= wpautop($a);
			elseif( $d['type'] == 'zip' || $d['type'] == 'apk_obb' )
				$output .= wpautop($b);    

			$output .= '</div>';

			return $output;
		}
	}
}

function px_last_slug_apk() {
	$lsa = appyn_options( 'edcgp_sapk_slug', true ); 
	return ( $lsa ) ? '-'.$lsa : '';
}

add_filter('wp_nav_menu_items','replace_class', 10, 2);

function replace_class($items, $args)  {
    if ($args->menu->slug == 'menu') {
		$items = px_content_filter($items);
	}

    return $items;

}

function px_logo() {
	$logo = appyn_options( 'logo');
	$logo = ( !empty($logo) ) ? $logo: get_bloginfo('template_url').'/images/logo.png';
	$logo_id = attachment_url_to_postid( $logo );
	if( empty($logo_id) ) {
		$m = array( 1 => 150, 2 => 40 );
	} else {
		$m = wp_get_attachment_image_src( $logo_id, 'full' );
	}
	echo '<img src="'.$logo.'" alt="'.get_bloginfo('title').'" width="'.$m[1].'" height="'.$m[2].'">'; 
}

function px_download_link($url) {
	$appyn_encrypt_links = appyn_options( 'encrypt_links' );

	if( $appyn_encrypt_links == 1 ) {
		return add_query_arg( 'download_link', px_encrypt_decrypt( 'encrypt', $url ), esc_url( remove_query_arg('amp', get_bloginfo('url') ) ) );
	}
	return $url;
}

function px_encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'SecretKey'.get_bloginfo('url');
    $secret_iv = 'SecretKeyIV'.get_bloginfo('url');
    $key = hash('sha256', $secret_key);
    
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

function px_option_selected_upload() {
	$tsr = appyn_options( 'edcgp_sapk_server' );

	if( $tsr == 2 ) {
		return __( 'Google Drive', 'appyn' ). ( ( !appyn_options( 'gdrive_token' ) ) ? ' '. __( '(No activado)', 'appyn' ) : '' );
	} elseif( $tsr == 3 ) {
		return __( 'Dropbox', 'appyn' ). (!appyn_options( 'dropbox_access_token' ) ?  ' '. __( '(Falta token de acceso)', 'appyn' ) : '' );
	} else {
		return __( 'Mi servidor', 'appyn' );
	} 
}