<?php

class Dropbox {

    var $access_token;
    var $filename; 
    var $max_upload; 
    var $content;
    var $filesize;
    var $session_id;

    public function __construct() {

        $this->access_token = appyn_options( 'dropbox_access_token', true );

        if( !$this->access_token ) {
            $output['error'] = __( 'Error: Falta token de acceso', 'appyn' );
            return $output;
        }

        $this->max_upload   = 150 * 1024 * 1024;
        
    }

    private function checkIfExists( $path_display ) {

        $curl_url = 'https://api.dropboxapi.com/2/sharing/list_shared_links';
        
        $content = array(
            'path' => $path_display,
        );
        $result = $this->curlInit( $curl_url, json_encode( $content ), false, 'json' );

        $r = json_decode( $result, true );
        
        if( count($r['links']) > 0 ) {
            return $r['links'][0]['url'];
        }
    }

    public function Upload( $filename ) {

        $this->filename     = $filename;
        $fp                 = fopen($this->filename, 'rb');
        $this->content      = fread($fp, $this->max_upload);
        $this->filesize     = filesize($this->filename);

        if( $this->filesize < $this->max_upload ) {
            $dropbox_api_arg = array(
                "path"=> '/'.basename( $this->filename ),
                "mode" => "add",
                "autorename" => true,
                "mute" => false,
                "strict_conflict" => false
            );
            
            $curl_url = 'https://content.dropboxapi.com/2/files/upload';
            $result = $this->curlInit( $curl_url, $this->content, $dropbox_api_arg );
            
            $r = json_decode($result, true);

            if( isset($r['error_summary']) ) {
                $output['error'] = $r['error_summary'];
                return $output;
            }

            $checkIfExists = $this->checkIfExists($r['path_display']);
    
            if( $checkIfExists ) {
                $output['url'] = $checkIfExists;
            } else {
                $dpd  = $this->pathDisplay($r['path_display']);
                $output['url'] = $dpd['url'];
            }
            return $output;

        } else {

            $offset = 0;
            while ( ! feof( $fp ) ) {
                if( $offset == 0 ) {

                    $this->uploadStart();

                    $offset += strlen( $this->content );
                    continue;

                }                

                if( $this->filesize == ( $offset + strlen($this->content) ) ) {				

                    $result = $this->uploadFinish($offset);  
    
                    return $result;

                    break;
                }

                $this->uploadAppend($offset);

                $offset += strlen( $this->content );

                if( $offset >= $this->filesize ) {
                    break;
                }
            }
        }

    }

    private function curlInit( $curl_url, $content, $dropbox_api_arg, $type = 'octet-stream' ) {

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $curl_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $content);
        curl_setopt($ch, CURLOPT_POST, 1);
        
        $headers = array();
        $headers[] = 'Authorization: Bearer '. $this->access_token;

        if( $dropbox_api_arg ) 
            $headers[] = 'Dropbox-Api-Arg: '. json_encode($dropbox_api_arg);

        if( $type == 'octet-stream' ) 
            $headers[] = 'Content-Type: application/octet-stream';
        elseif( $type == 'json' ) 
            $headers[] = 'Content-Type: application/json';

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $result = curl_exec($ch);

        if (curl_errno($ch)) {
            $output['error'] = "curl: ". curl_error($ch);
            return $output;
        }

        curl_close ($ch);

        return $result;

    }

    private function uploadStart() {
        
        $curl_url = 'https://content.dropboxapi.com/2/files/upload_session/start';
        $dropbox_api_arg = array(
            "close"=> false,
        );
        $result = $this->curlInit( $curl_url, $this->content, $dropbox_api_arg );
        
        $r = json_decode($result, true);
        $this->session_id = $r['session_id'];

        if( ! $this->session_id || $this->session_id == 'None' ) {
            $output['error'] = __( 'Error: Token de acceso incorrecto', 'appyn' );
            return $output;
        }
        return $r;

    }

    private function uploadFinish( $offset ) {

        $output = array();
        $curl_url = 'https://content.dropboxapi.com/2/files/upload_session/finish';
        $dropbox_api_arg = array(
            "cursor" => array(
                "session_id" => $this->session_id,
                "offset" => $offset,
            ),
            "commit" => array(
                "path"=> '/'.basename($this->filename),
                "mode" => "add",
                "autorename" => true,
                "mute" => false,
                "strict_conflict" => false
            )
        );
        $result = $this->curlInit( $curl_url, $this->content, $dropbox_api_arg );

        $r = json_decode($result, true);

        if( isset($r['error_summary']) ) {
            $output['error'] = $r['error_summary'];
            return $output;
        }

        $dpd  = $this->pathDisplay($r['path_display']);
        $output['url'] = $dpd['url'];

        return $output;  

    }

    private function uploadAppend( $offset ) {

        $curl_url = 'https://content.dropboxapi.com/2/files/upload_session/append_v2';
        $dropbox_api_arg = array(
            "cursor" => array(
                "session_id" => $this->session_id,
                "offset" => $offset,
            ),
            "close" => false,
        );

        $this->curlInit( $curl_url, $this->content, $dropbox_api_arg );

    }

    private function pathDisplay($path_display) {

        $curl_url = 'https://api.dropboxapi.com/2/sharing/create_shared_link_with_settings';

        $content = array(
            'path' => $path_display,
            "settings" => array(
                "requested_visibility" => "public",
                "audience" => "public",
                "access" => "viewer",
            ),
        );

        $result = $this->curlInit( $curl_url, json_encode( $content ), false, 'json' );
        $r = json_decode($result, true);

        return $r;

    }
}