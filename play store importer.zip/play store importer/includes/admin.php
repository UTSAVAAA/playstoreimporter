<?php

if ( !defined('NONCE_KEY') ) die('Acceso no permitido');

include_once __DIR__."/../admin/panel.php";

function load_custom_wp_admin_style() {
	wp_enqueue_style( 'style-admin', get_bloginfo("template_directory").'/admin/assets/css/style.css', false, VERSIONPX, 'all' ); 

	wp_enqueue_style( 'style-font-awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', false, false, 'all' ); 

	wp_enqueue_style( 'wp-color-picker' );

	wp_enqueue_style('thickbox');

}
add_action( 'admin_enqueue_scripts', 'load_custom_wp_admin_style' );

function load_custom_wp_admin_scripts() {
	wp_enqueue_script('jquery-ui-sortable');

	wp_enqueue_script( 'media-upload' );

	wp_enqueue_script( 'thickbox' );

	wp_enqueue_script( 'my-upload' );

	wp_register_script( 'custom-upload', get_bloginfo('template_url').'/admin/assets/js/upload.js',array('jquery','media-upload','thickbox') );

	wp_enqueue_script( 'custom-upload' );

	wp_enqueue_script( 'colorpicker-custom', get_bloginfo("template_directory").'/admin/assets/js/colorpicker.js', array( 'wp-color-picker' ), false, true );
	
	wp_enqueue_script( 'admin-js', get_bloginfo("template_directory").'/admin/assets/js/js.js', false, VERSIONPX, true ); 
    wp_localize_script( 'admin-js', 'ajax_var', array(
        'url'    => admin_url( 'admin-ajax.php' ),
        'nonce'  => wp_create_nonce( 'admin_panel_nonce' ),
        'action' => 'px_panel_admin',
		'error_text' => __( 'Ocurrió un error', 'appyn' ),
    ) );
    wp_localize_script( 'admin-js', 'importgp_nonce', array(
        'nonce'  => wp_create_nonce( 'importgp_nonce' )
    ) );
}
add_action( 'admin_enqueue_scripts', 'load_custom_wp_admin_scripts' );


function admin_notice_update() {
	$url = 'https://themespixel.net/api.php?theme='.THEMEPX;
	$data = get_remote_html( $url );
	$result = json_decode($data, TRUE);
	if( $result && VERSIONPX < $result['version'] ) {
    ?><?php add_thickbox(); ?>
		<?php $user_locale = strstr(get_user_locale(), '_', true); ?>
    <div class="notice notice-success is-dismissible">
		<p><?php echo sprintf(__( 'Está disponible una nueva versión del theme %s', 'appyn' ), ucfirst(THEMEPX)); ?> . <a href="https://themespixel.net/changelog.php?theme=<?php echo THEMEPX; ?>&lang=<?php echo $user_locale; ?>&TB_iframe=true&width=550&height=450" class="thickbox"><?php echo sprintf(__( 'Revisa los detalles de la versión %s', 'appyn' ), $result['version']); ?></a>. <a href="https://themespixel.net/login/" target="_blank"><?php echo __( 'Descárgala ahora', 'appyn' ); ?></a>.</p>
    </div>
    <?php
	}
}
add_action( 'admin_notices', 'admin_notice_update' );



function rd_duplicate_post_as_draft(){
	global $wpdb;
	if (! ( isset( $_GET['post']) || isset( $_POST['post'])  || ( isset($_REQUEST['action']) && 'rd_duplicate_post_as_draft' == $_REQUEST['action'] ) ) ) {
		wp_die('No post to duplicate has been supplied!');
	}
 
	if ( !isset( $_GET['duplicate_nonce'] ) || !wp_verify_nonce( $_GET['duplicate_nonce'], basename( __FILE__ ) ) )
		return;
	$post_id = (isset($_GET['post']) ? absint( $_GET['post'] ) : absint( $_POST['post'] ) );
	$post = get_post( $post_id );
 
	$current_user = wp_get_current_user();
	$new_post_author = $current_user->ID;
 
	if (isset( $post ) && $post != null) {
 
		$info = get_post_meta( $post->ID, 'datos_informacion', true );
		$post_title = $post->post_title;
		if( !empty( $info['version'] ) ) {
			$post_title .= ' '.$info['version'];
		}
		$args = array(
			'comment_status' => $post->comment_status,
			'ping_status'    => $post->ping_status,
			'post_author'    => $new_post_author,
			'post_content'   => $post->post_content,
			'post_excerpt'   => $post->post_excerpt,
			'post_name'      => $post->post_name,
			'post_parent'    => $post->post_parent,
			'post_password'  => $post->post_password,
			'post_status'    => 'publish',
			'post_title'     => $post_title,
			'post_type'      => $post->post_type,
			'to_ping'        => $post->to_ping,
			'menu_order'     => $post->menu_order,
			'post_parent'	 => $post_id,
		);

		$new_post_id = wp_insert_post( $args );
			remove_action( 'save_post', 'rd_duplicate_post_as_draft', 10, 3 );
			wp_update_post( array(
				'ID' => $new_post_id,
				'post_date' => $post->post_date,
				'post_date_gmt' => $post->post_date_gmt,
				'post_name' => sanitize_title( $post_title ),
			));
			wp_update_post( array(
				'ID' => $post->ID,
				'post_date' => the_date('', '', '', FALSE),
				'post_date_gmt' => the_date('', '', '', FALSE),
			));

			add_action( 'save_post', 'rd_duplicate_post_as_draft', 10, 3 );
 
		$taxonomies = get_object_taxonomies($post->post_type); 
		foreach ($taxonomies as $taxonomy) {
			$post_terms = wp_get_object_terms($post_id, $taxonomy, array('fields' => 'slugs'));
			wp_set_object_terms($new_post_id, $post_terms, $taxonomy, false);
		}
 
		$post_meta_infos = $wpdb->get_results("SELECT meta_key, meta_value FROM $wpdb->postmeta WHERE post_id=$post_id");
		if (count($post_meta_infos)!=0) {
			$sql_query = "INSERT INTO $wpdb->postmeta (post_id, meta_key, meta_value) ";
			foreach ($post_meta_infos as $meta_info) {
				$meta_key = $meta_info->meta_key;
				if( $meta_key == '_wp_old_slug' ) continue;
				$meta_value = addslashes($meta_info->meta_value);
				$sql_query_sel[]= "SELECT $new_post_id, '$meta_key', '$meta_value'";
			}
			$sql_query.= implode(" UNION ALL ", $sql_query_sel);
			$wpdb->query($sql_query);
		}
 
		wp_redirect( admin_url( 'post.php?action=edit&post=' . $new_post_id ) );
		exit;
	} else {
		wp_die('Post creation failed, could not find original post: ' . $post_id);
	}
}
add_action( 'admin_action_rd_duplicate_post_as_draft', 'rd_duplicate_post_as_draft' );

function rd_duplicate_post_link( $actions, $post ) {
	if( current_user_can('edit_posts') && $post->post_parent == 0 && $post->post_status == "publish" && $post->post_type == "post" ) {
		$actions['duplicate'] = '<a href="' . wp_nonce_url('admin.php?action=rd_duplicate_post_as_draft&post=' . $post->ID, basename(__FILE__), 'duplicate_nonce' ) . '" title="'.__( 'Convertir en versión anterior', 'appyn' ).'" rel="permalink">'.__( 'Convertir en versión anterior', 'appyn' ).'</a>';
	}
	return $actions;
}
add_filter('page_row_actions', 'rd_duplicate_post_link', 10, 2);


add_action( 'admin_bar_menu', 'toolbar_admin_reports', 999 );
function toolbar_admin_reports( $wp_admin_bar ) {
	$args = array(
		'id'    => 'menu_reports',
		'title' => '<span class="ab-icon"></span><span class="ab-label">'.count_reports().'</span>',
		'href'  => admin_url().'admin.php?page=appyn_reports',
		'meta'  => array( 'class' => 'tbap-report'),
		'parent' => false, 
	);
	$wp_admin_bar->add_node( $args );
}
add_action( 'admin_bar_menu', 'toolbar_admin_px', 999 );
function toolbar_admin_px( $wp_admin_bar ) {
	$post_id = ( isset($_GET['post']) ) ? $_GET['post'] : NULL;
	$args = array(
		'id'    => 'appyn_importar_contenido_gp',
		'title' => '<span class="ab-icon"></span><span class="ab-label">'.__( 'Importar contenido (Google Play)', 'appyn' ).' </span>',
		'href'  => admin_url().'admin.php?page=appyn_importar_contenido_gp',
		'meta'  => array( 'class' => 'tbap-ipcgp'),
		'parent' => false, 
	);
	$wp_admin_bar->add_node( $args );
	if( $post_id ) {
		if( get_post_type($post_id) == "post" ) {
			$args = array(
				'id'    => 'appyn_actualizar_informacion',
				'title' => '<span class="ab-icon"></span><span class="ab-label">'.__( 'Actualizar información', 'appyn' ).'</span>',
				'href'  => 'javascript:void(0)',
				'meta'  => array( 
					'class' => 'tbap-update', 
				),
				'parent' => false, 
			);
			$wp_admin_bar->add_node( $args );	
		}

		if( wp_get_post_parent_id($post_id) ) {
			$args = array(
				'id'    => 'appyn_view_post_parent',
				'title' => '<span class="ab-label">'.__( 'Ver post padre', 'appyn' ).'</span>',
				'href'  => get_edit_post_link( wp_get_post_parent_id($post_id) ),
				'parent' => false, 
			);
			$wp_admin_bar->add_node( $args );	
		}
	}
}

function css_admin_bar() { ?>
	<style type="text/css">
		.tbap-report .ab-icon::before,
		.tbap-update .ab-icon::before,
		.tbap-ipcgp .ab-icon::before {
			content: "\f534";
			display: inline-block;
			-webkit-font-smoothing: antialiased;
			font-family: 'dashicons';
			font-display: 'swap';
			vertical-align: middle;
			position: relative;
			top: -3px;
		}
		#wpadminbar #wp-admin-bar-appyn_importar_contenido_gp {
			background: rgba(255,255,255,0.2);
			display: block;
		} 
		.tbap-ipcgp .ab-icon::before {
			content: "\f18b";
            height: 19px;
		}
		.tbap-update .ab-icon::before {
			content: "\f113";
            height: 19px;
		}
        .tbap-update.wait .ab-icon {
            animation: infinite-spinning 2s infinite;
            -webkit-animation: infinite-spinning 2s infinite;
            -webkit-animation-timing-function: linear;
            animation-timing-function: linear;
        }
		@media (max-width:768px) {
			.tbap-ipcgp .ab-icon::before {
				line-height: 1.33333333;
				height: 46px!important;
				text-align: center;
				width: 52px;
				font-size: 33px;
				vertical-align: inherit;
				top: 0;
			}
		}
        @keyframes infinite-spinning {
            from {
                transform: rotate(0deg);
            }
            to {
                transform: rotate(-360deg);
            }
        }
	</style>
<?php }
add_action( 'admin_head', 'css_admin_bar' );
add_action( 'wp_head', 'css_admin_bar' );

add_action( 'admin_head', 'url_eps_update' );
function url_eps_update() {
	?>
	<script>
		var url_eps_update = "<?php echo get_template_directory_uri(); ?>/admin/eps_update.php";
    	var url_eps_publish = "<?php echo get_template_directory_uri(); ?>/admin/eps_publish.php";
		var text_confirm_update = "<?php echo __( '¿Quiere actualizar la información de esta aplicación? Recuerda que reemplazará toda la información.', 'appyn' ); ?>";
	</script>
<?php }