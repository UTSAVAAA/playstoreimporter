<?php get_header(); ?>
  <div class="container">
   <div class="page-woocommerce">
	<?php woocommerce_content(); ?>
   </div>
   <?php get_sidebar(); ?>
  </div>
<?php get_footer(); ?>