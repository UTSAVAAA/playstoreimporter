<?php

if( !defined('ABSPATH') ) die ( '✋');

add_action('admin_menu', 'appyn_theme');
function appyn_theme() {
	add_menu_page( 'Appyn', 'Appyn', 'manage_options', 'appyn_panel', 'appyn_settings', get_bloginfo('template_url').'/images/ico-panel.png', 81 );
	
	add_submenu_page( 'appyn_panel', 'Panel', 'Panel', 'manage_options', 'appyn_panel' );
	add_submenu_page( 'appyn_panel', __( 'Documentación', 'appyn' ), __( 'Documentación', 'appyn' ), 'manage_options', 'appyn_documentation', 'appyn_documentation' );
	add_submenu_page( 'appyn_panel', 'Changelog', 'Changelog', 'manage_options', 'appyn_changelog', 'appyn_changelog' );
	add_submenu_page( 'appyn_panel', __( 'Reportes', 'appyn' ), __( 'Reportes', 'appyn' ).' <span class="awaiting-mod count-3"><span class="pending-count">'.appyn_count_reports().'</span></span>', 'manage_options', 'appyn_reports', 'appyn_reports' );
	
	$roles = appyn_options( 'edcgp_roles' );
	if( $roles == "0" ) {
		$roles = 'administrator';
	}
	if( $roles == 'administrator' ) {
		$capability = 'manage_options';
	} 
	if( $roles == 'editor' ) {
		$capability = 'moderate_comments';
	} 
	if( $roles == 'author' ) {
		$capability = 'publish_posts';
	}
	if( $roles == 'contributor' ) {
		$capability = 'read';
	}
	add_submenu_page( 'appyn_importar_contenido_gp', __( 'Importar contenido (Google Play)', 'appyn' ), __( 'Importar contenido (Google Play)', 'appyn' ), $capability, 'appyn_importar_contenido_gp', 'appyn_importar_contenido_gp' );
}
function appyn_importar_contenido_gp(){

	echo '<h3>'.__( 'Importar contenido (Google Play)', 'appyn' ).'</h3>';
	echo '<div class="extract-box">
			<form id="form-import">
				<input type="text" class="widefat" id="url_googleplay" name="" value="" placeholder="URL GooglePlay" spellcheck="false"><input type="submit" class="button button-primary button-large" id="importar" value="'.__( 'Importar datos', 'appyn' ).'"><span class="spinner"></span>
			</form>
		</div>';
	echo '
	<p><em>'.__( 'Al hacer clic en "Importar datos" se creará un post con toda la información importada basándose en las opciones mostradas a continuación...', 'appyn' ).'</em></p>
	<h3>'.__( 'Opciones al importar datos', 'appyn' ).'</h3>
	<ul>
		<li>'.__( 'Estado del post', 'appyn' ).':</strong> <strong>'.( (appyn_options('edcgp_post_status') == 1 ) ? __( 'Publicado', 'appyn' ) : __( 'Borrador', 'appyn' ) ).'</strong></li>
		<li>'.__( 'Crear categoría si no existe', 'appyn' ).':</strong> <strong>'.( (appyn_options('edcgp_create_category') == 1 ) ? __( 'No', 'appyn' ) : __( 'Sí', 'appyn' ) ) .'</strong></li>		
 		<li>'.__( 'Crear taxonomía <i>Desarrollador</i> si no existe', 'appyn' ).': <strong>'.( (appyn_options('edcgp_create_tax_dev') == 1 ) ? __( 'No', 'appyn' ) : __( 'Sí', 'appyn' ) ) .'</strong></li>		
		<li>'.__( 'Obtener APK', 'appyn' ).': <strong>'.( (appyn_options('edcgp_sapk') ) ? __( 'No', 'appyn' ) : __( 'Sí', 'appyn' ) ) .'</strong></li>';
		
		if( appyn_options('edcgp_sapk') == 0 ) {
			echo '<li>'.__( 'Servidor de subida', 'appyn' ).': <strong>'. px_option_selected_upload() .'</strong></li> ';
		}
		echo '
		<li>'.__( 'Cantidad de imágenes importadas', 'appyn' ).': <strong>'.( (appyn_options('edcgp_extracted_images') ) ? appyn_options('edcgp_extracted_images') : 5) .'</strong></li>
		<li>'.__( 'Rating', 'appyn' ).': <strong>'.( (appyn_options('edcgp_rating') ) ? __( 'Sí', 'appyn' ) : __( 'No', 'appyn' ) ) .'</strong></li>
		<li>'.__( 'Apps duplicadas', 'appyn' ).': <strong>'.( (appyn_options('edcgp_appd') == 1 ) ? __( 'Sí', 'appyn' ) : __( 'No', 'appyn' ) ) .'</strong></li>
	</ul>';
	echo '<p><a href="'.admin_url().'admin.php?page=appyn_panel#edcgp">'.__( 'Cambiar opciones', 'appyn' ).'</a></p>';
}
function appyn_count_reports(){
	global $wpdb;
	$results = $wpdb->get_results( "SELECT meta_value, post_id FROM ".$wpdb->prefix."postmeta WHERE meta_key = 'px_app_report' ORDER BY meta_id DESC");
	return $wpdb->num_rows;
}
function appyn_reports(){
	global $wpdb, $post;
	if( isset($_POST['appyn_reports']) ) {
		foreach( $_POST['posts_id'] as $id ) {
			delete_post_meta( $id, 'px_app_report' );
		}
	}
	$results = $wpdb->get_results( "SELECT meta_value, post_id FROM ".$wpdb->prefix."postmeta WHERE meta_key = 'px_app_report' ORDER BY meta_id DESC");
?>
	<div class="wrap">
		<h1><?php echo __( 'Reportes', 'appyn' ); ?></h1>
		<p><?php printf( _nx( __( '%s entrada reportada', 'appyn' ), __( '%s entradas reportadas', 'appyn' ), $wpdb->num_rows, 'group of people', 'appyn' ), $wpdb->num_rows ); ?></p>
		<form action="" method="post" class="form-report">
			<table class="wp-list-table widefat fixed striped table-report">
				<thead>
					<tr>
						<td class="check-column"><input type="checkbox" class="tr-checkall"></td>
						<th class="manage-column" style="width: 35%;"><?php echo __( 'Título', 'appyn' ); ?></th>
						<th class="manage-column" style="width: 45%;"><?php echo __( 'Detalles', 'appyn' ); ?></th>
						<th class="manage-column" style="width: 15%;"><?php echo __( 'Acción', 'appyn' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if( $results ) : foreach( $results as $post ) :
					$info = get_post_meta( $post->post_id, 'px_app_report', true );
					$info = json_decode( $info, true );
					?>
					<tr>
						<td><input type="checkbox" name="posts_id[]" value="<?php echo $post->post_id; ?>"></td>
						<td><a href="<?php echo get_edit_post_link( $post->post_id ); ?>" target="_blank" title="<?php echo __( 'Editar post', 'appyn' ); ?>"><?php echo get_the_title( $post->post_id ); ?></a></td>
						<td>
						<ol style="margin-top:0;">
						<?php 
						$info = array_reverse($info);
						foreach( $info as $f ) {
							echo "<li>".options_report( $f['option'] )."<br>";
							echo nl2br(stripslashes($f['details']))."<br></li>";
						}
						?>
						</ol>
						<td><a href="<?php echo get_the_permalink( $post->post_id ); ?>" target="_blank"><?php echo __( 'Ver post', 'appyn' ); ?></a></td>
					</tr>
					<?php endforeach;	
					else :
					?>
					<tr>
						<td colspan="100%" style="text-align: center;"><?php echo __( 'No hay reportes', 'appyn' ); ?></td>
					</tr>
					<?php
					endif; ?>
				</tbody>
			</table>
			<?php if( $results ) : ?>
			<p><input type="submit" class="button button-primary button-large" value="<?php echo __( 'Borrar reportes', 'appyn' ); ?>" name="appyn_reports"></p>
			<?php endif; ?>
		</form>
	</div>
<script type="text/javascript">
	jQuery(function($) {
		$('.tr-checkall').on('click', function() {
			if( $(this).is(':checked') ) {
				$('.table-report tbody input[type="checkbox"]').prop('checked', true);
			} else {
				$('.table-report tbody input[type="checkbox"]').prop('checked', false);
			}
		});
		$('.table-report tbody input[type="checkbox"]').on('click', function(){
			var is_checked_all = true;
			$('.table-report tbody input[type="checkbox"]').each(function(index, item){
				if( !$(this).is(':checked') ) {
					is_checked_all = false;
				}
			});
			if( is_checked_all ) {
				$('.tr-checkall').prop('checked', true);
			} else {
				$('.tr-checkall').prop('checked', false);
			}
		});
		$('.form-report').on('submit', function(e){
			var is_checked = false;
			$('.table-report tbody input[type="checkbox"]').each(function(index, item){
				if( $(this).is(':checked') ) {
					is_checked = true;
				}
			});
			if( !is_checked ) {
				e.preventDefault();
			}
		});
	});
</script>
<?php
}
function appyn_changelog(){ 
	echo '<script type="text/javascript">window.location="https://themespixel.net/'.( (lang_wp() == "en") ? 'en/' : '' ).'changelog/appyn/";</script>';
}
function lang_wp(){
	if( function_exists( 'icl_object_id' ) ){ //WPML
		$lang = ICL_LANGUAGE_CODE;
	} else {
		$lang = strstr(get_user_locale(), '_', true);
	}
	return $lang;
}
function appyn_documentation(){ 
	echo '<script type="text/javascript">window.location="https://themespixel.net/'.( (lang_wp() == "en") ? 'en/' : '' ).'docs/appyn/";</script>';
}
function appyn_settings(){ ?> 
<div id="panel_theme_tpx">
    <div class="pttbox">
    	<form method="post" id="form-panel">
    		<div id="menu">
     			<ul>
      				<li style="background:#FFF; padding:10px 15px;"><b>Theme: </b>Appyn<br>
						  <b><?php echo __( 'Versión', 'appyn' ); ?>: </b><?php echo VERSIONPX; ?><br>
					</li>						  
                    <li>
						<a href="#general"><i class="fa fa-cog"></i> <?php echo __( 'Opciones generales', 'appyn' ); ?></a>
					</li>
                    <li>
						<a href="#home"><i class="fa fa-home"></i> <?php echo __( 'Home', 'appyn' ); ?></a>
					</li>
                    <li>
						<a href="#single"><i class="fa fa-file"></i> <?php echo __( 'Single', 'appyn' ); ?></a>
					</li>
                    <li>
						<a href="#edcgp"><i class="fa fa-google" aria-hidden="true"></i> <?php echo __( 'Importador de contenido', 'appyn' ); ?></a>
					</li>
                    <li>
						<a href="#historial_versiones"><i class="fa fa-history"></i> <?php echo __( 'Historial de versiones', 'appyn' ); ?></a>
					</li>
                    <li>
						<a href="#blog"><i class="fa fa-th-large"></i> <?php echo __( 'Blog', 'appyn' ); ?></a>
					</li>
                    <li>
						<a href="#color"><i class="fa fa-adjust"></i> <?php echo __( 'Colores', 'appyn' ); ?></a>
					</li>
                    <li>
						<a href="#sidebar"><i class="fa fa-list-ul"></i> <?php echo __( 'Sidebar', 'appyn' ); ?></a>
					</li>
                    <li>
						<a href="#ads"><i class="fa fa-money"></i> <?php echo __( 'Anuncios', 'appyn' ); ?></a>
					</li>
                    <li>
						<a href="#amp"><i class="fa fa-bolt"></i> <?php echo __( 'AMP', 'appyn' ); ?></a>
					</li>
                    <li>
						<a href="#footer"><i class="fa fa-terminal"></i> <?php echo __( 'Footer', 'appyn' ); ?></a>
					</li>
                    <li><div class="submit" style="clear:both">
                        <input type="submit" name="Submit" class="button-primary" value="<?php echo __( 'Guardar cambios', 'appyn' ); ?>">
                        <input type="hidden" name="appyn_settings" value="save">
                        </div></li>
     			</ul>
    		</div>
            <div class="section" data-section="home">
				<h2><?php echo __( 'Home', 'appyn' ); ?></h2>

				<table class="table-main">			

					<tr>
						<td><h3><?php echo __( 'Título', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Coloca el título del Home', 'appyn' ); ?>.</div></td>
						<td>
						<input type="text" name="titulo_principal" value="<?php echo get_option( 'appyn_titulo_principal' ); ?>" class="widefat"></td>
					</tr>

					<tr>
						<td><h3><?php echo __( 'Descripción', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Coloca la descripción del Home', 'appyn' ); ?>.</div></td>
						<td><textarea name="descripcion_principal" class="widefat" rows="5" spellcheck="false"><?php echo stripslashes(get_option( 'appyn_descripcion_principal' )); ?></textarea></td>
					</tr>

					<tr>
						<td><h3><?php echo __( 'Imágenes de Portada', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Sube hasta 5 imágenes para que aparezca en el Home aleatoriamente. De preferencia imágenes mayores de 1300px de ancho y 300px de altura', 'appyn' ); ?>.</div></td>
						<td>
							<table class="sub-table">
								<?php for($n=1;$n<=5;$n++) { ?>
								<tr>
									<td>
										<div class="regular-text-download">
											<input type="text" name="image_header<?php echo $n; ?>" value="<?php echo get_option('appyn_image_header'.$n); ?>" class="regular-text">
											<input class="upload_image_button" type="button" value="&#xf093;">
										</div>
									</td>
								</tr>
								<?php } ?>
							</table>
						</td>
					</tr>

					<tr>
						<td><h3><?php echo __( 'Apps más calificadas', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Slider con las aplicaciones más descargadas.', 'appyn' ); ?></div>
						</td>
						<td>
							<?php
							$mas_calificadas = get_option( 'appyn_mas_calificadas' );
							$mas_calificadas_limite = get_option( 'appyn_mas_calificadas_limite' );
							$mas_calificadas_limite = (empty($mas_calificadas_limite)) ? '5' : $mas_calificadas_limite;
							?>
							<p><label class="switch"><input type="checkbox" name="mas_calificadas" value="1" <?php checked( $mas_calificadas, 1 ); ?>><span class="swisr"></span></label></p>
							<?php
							$mas_calificadas_limite = get_option( 'appyn_mas_calificadas_limite' );
							$mas_calificadas_limite = (empty($mas_calificadas_limite)) ? '5' : $mas_calificadas_limite;
							echo '<input type="number" name="mas_calificadas_limite" size="2" value="'.$mas_calificadas_limite.'" class="input_number" required> '.__( 'Entradas', 'appyn' );							
							?>
						</td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Ocultar entradas', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Oculta las entradas del inicio.', 'appyn' ); ?></div>
						</td>
						<td>
							<?php $h = appyn_options( 'home_hidden_posts' ); ?>
							<p><label class="switch"><input type="checkbox" name="home_hidden_posts" value="1" <?php checked( $h, 1 ); ?>><span class="swisr"></span></label></p>
						</td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Entradas por página', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Límite de entradas.', 'appyn' ); ?></div>
						</td>
						<td><?php
							$home_limite = get_option( 'appyn_home_limite' );
							$home_limite = (empty($home_limite)) ? '12' : $home_limite;
							echo '<input type="number" name="home_limite" size="2" value="'.$home_limite.'" class="input_number" required> '.__( 'Entradas', 'appyn' ) ?></td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Orden de las entradas', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Ordena las entradas del Home por fecha, por modificación o aleatorio.', 'appyn' ); ?></div>
						</td>
						<td><?php $home_posts_orden = get_option( 'appyn_home_posts_orden' ); ?>
						
							<p><label><input type="radio" name="home_posts_orden" value="0" <?php checked( $home_posts_orden, 0 ); ?>> <?php echo __( 'Por fecha (Defecto)', 'appyn' ); ?></label></p>

							<p><label><input type="radio" name="home_posts_orden" value="modified" <?php checked( $home_posts_orden, 'modified' ); ?>> <?php echo __( 'Por modificación', 'appyn' ); ?></label></p>

							<p><label><input type="radio" name="home_posts_orden" value="rand" <?php checked( $home_posts_orden, 'rand' ); ?>> <?php echo __( 'Aleatorio', 'appyn' ); ?></label></p>
						</td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Posts Categorías Home', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Escoge qué categorías y cuántos de estos quieres que aparezca en el Home debajo de los últimos posts', 'appyn' ); ?>.</div>
						</td>
						<td><p><?php
							$categorias_home = get_option( 'appyn_categories_home' );
							if( function_exists( 'icl_object_id' ) ){ //WPML
								$categorias_home = lang_object_ids($categorias_home,'category');
							}
                            $categories = get_categories(array( 'hide_empty'=> 0));

							foreach($categories as $cat) {
								if(!empty($categorias_home)){
									if(@in_array($cat->term_id, $categorias_home)){
										echo '<label><input type="checkbox" name="categories_home[]" value="'.$cat->term_id.'" checked> '.$cat->name .'('.$cat->count.')</label><br>';
									} else {
										echo '<label><input type="checkbox" name="categories_home[]" value="'.$cat->term_id.'"> '.$cat->name.' ('.$cat->count.')</label><br>';
									}
								} else {
										echo '<label><input type="checkbox" name="categories_home[]" value="'.$cat->term_id.'"> '.$cat->name.' ('.$cat->count.')</label><br>';
								}
							}?></p>
                            <?php
							$categories_home_limite = get_option( 'appyn_categories_home_limite' );
							$categories_home_limite = (empty($categories_home_limite)) ? '6' : $categories_home_limite;
							echo '<input type="number" name="categories_home_limite" size="2" value="'.$categories_home_limite.'" class="input_number" required> ' . __( 'Entradas', 'appyn' );
							?>
							</td>
					</tr>
				</table>
			</div>

            <div class="section" data-section="edcgp">
				<h2><?php echo __( 'Importador de contenido', 'appyn' ); ?></h2>
					
					<table class="table-main">
						<tr>
							<td><h3><?php echo __( 'API Key', 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( 'Clave única que se necesita para poder utilizar el importador de contenido.', 'appyn' ); ?> <a href="https://themespixel.net/docs/appyn/api-key/" target="_blank"><?php echo __( '¿Cómo obtengo el mio?', 'appyn' ); ?></a></div>
							</td>
							<td><input type="text" name="apikey" id="apikey" value="<?php echo appyn_options( 'apikey', true ); ?>" class="widefat"></td>
						</tr>
						<tr>
							<td><h3><?php echo __( 'Roles', 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( 'Tipo de usuario a quienes aparecerá el importador de contenido.', 'appyn' ); ?> 
								</div>
							</td>
							<td>
								<?php 
								$roles = appyn_options( 'edcgp_roles' );
								?>
								<select name="edcgp_roles">
									<option value="administrator"<?php selected(0, $roles); ?><?php selected('administrator', $roles); ?>><?php echo __( 'Administrador', 'appyn'); ?></option>
									<option value="editor"<?php selected('editor', $roles); ?>><?php echo __( 'Administrador y Editor', 'appyn'); ?></option>
									<option value="author"<?php selected('author', $roles); ?>><?php echo __( 'Administrador, Editor y Autor', 'appyn'); ?></option>
									<option value="contributor"<?php selected('contributor', $roles); ?>><?php echo __( 'Administrador, Editor, Autor y Colaborador', 'appyn'); ?></option>
								</select>
							</td>
						</tr>
						<tr>
							<td><h3><?php echo __( 'Estado del post', 'appyn'); ?></h3></td>
							<td><?php $edcgp_post_status = appyn_options( 'edcgp_post_status' ); ?>
								
								<p><label><input type="radio" name="edcgp_post_status" value="0" <?php checked( $edcgp_post_status, 0 ); ?>> <?php echo __( 'Borrador', 'appyn' ); ?></label></p>

								<p><label><input type="radio" name="edcgp_post_status" value="1" <?php checked( $edcgp_post_status, 1 ); ?>> <?php echo __( 'Publicado', 'appyn' ); ?></label></p>
							</td>
						</tr>
						<tr>
							<td><h3><?php echo __( 'Crear categoría', 'appyn'); ?></h3>
								<div class="descr"><?php echo __( 'Crea la categoría si no existe', 'appyn' ); ?></div>
							</td>
							<td><?php $edcgp_create_category = appyn_options( 'edcgp_create_category' ); ?>
								<label class="switch"><input type="checkbox" name="edcgp_create_category" value="0" <?php checked( $edcgp_create_category, "0"); ?>><span class="swisr"></span></label>
							</td>
						</tr>
						<tr>
							<td><h3><?php echo __( "Crear taxonomía 'Desarrollador'", 'appyn'); ?></h3>
								<div class="descr"><?php echo __( "Crea la taxonomía 'Desarrollador' si no existe", 'appyn' ); ?></div>
							</td>
							<td><?php $edcgp_create_tax_dev = appyn_options( 'edcgp_create_tax_dev' ); ?>
								<label class="switch"><input type="checkbox" name="edcgp_create_tax_dev" value="0" <?php checked( $edcgp_create_tax_dev, "0"); ?>><span class="swisr"></span></label>
							</td>
						</tr>
						<tr>
							<td><h3><?php echo __( "Obtener APK", 'appyn'); ?></h3></td>
							<td><?php 
								$edcgp_sapk = appyn_options( 'edcgp_sapk' );
								$edcgp_sapk_server = appyn_options( 'edcgp_sapk_server' ); 
								$edcgp_sapk_slug = appyn_options( 'edcgp_sapk_slug', true ); 
								?>						
								<label class="switch switch-show" data-sshow="edcgp_sapk_server" data-svalue="0"><input type="checkbox" name="edcgp_sapk" value="0" <?php checked( $edcgp_sapk, "0"); ?>><span class="swisr"></span></label>
							</td>
						</tr>
						<tr>
							<td><h3><?php echo __( "Servidor de subida", 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( "Seleccionar servidor para subir los archivos APK.", 'appyn' ); ?></div>
							</td>
							<td><select name="edcgp_sapk_server">
									<option value="1"<?php echo selected($edcgp_sapk_server, 1); ?>><?php echo __( 'Mi servidor', 'appyn' ); ?></option>
									<option value="2"<?php echo selected($edcgp_sapk_server, 2); ?>><?php echo __( 'Google Drive', 'appyn' ); ?></option>
									<option value="3"<?php echo selected($edcgp_sapk_server, 3); ?>><?php echo __( 'Dropbox', 'appyn' ); ?></option>
								</select></td>
						</tr>
						<tr>
							<td><h3><?php echo __( "Slug", 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( "Agrega automáticamente un texto al final del nombre del archivo.", 'appyn' ); ?></div>
							</td>
							<td><input type="text" name="edcgp_sapk_slug" value="<?php echo $edcgp_sapk_slug; ?>" class="widefat"><br>
								<p><em><?php echo __( 'Ejemplo', 'appyn' ); ?>: com-file-<b><?php echo ( $edcgp_sapk_slug ) ? $edcgp_sapk_slug : 'example'; ?></b>.apk</em></p>
							</td>
						</tr>
						<tr>
							<td><h3><?php echo __( "Capturas de pantalla", 'appyn'); ?></h3>
								<div class="descr"><?php echo __( 'Cantidad de capturas de pantalla de la aplicación.', 'appyn' ); ?></div>
							</td>
							<td><?php $edcgp_extracted_images = appyn_options( 'edcgp_extracted_images' ); ?>
								<input type="number" name="edcgp_extracted_images" value="<?php echo ($edcgp_extracted_images) ? $edcgp_extracted_images : 5; ?>" class="input_number"> <?php echo __( 'Capturas', 'appyn'); ?></td>
						</tr>
						<tr>
							<td><h3><?php echo __( "Rating", 'appyn'); ?></h3>
								<div class="descr"><?php echo __( 'Tomar las calificaciones de la aplicación.', 'appyn' ); ?></div>
							</td>
							<td><?php $edcgp_rating = appyn_options( 'edcgp_rating' ); ?>
								<label class="switch"><input type="checkbox" name="edcgp_rating" value="1" <?php checked( $edcgp_rating, 1 ); ?>><span class="swisr"></span></label></td>	
						</tr>
						<tr>
							<td><h3><?php echo __( "Apps duplicadas", 'appyn'); ?></h3>
								<div class="descr"><?php echo __( 'Poder importar aplicaciones duplicadas', 'appyn' ); ?></div>
							</td>
							<td><?php $edcgp_appd = appyn_options( 'edcgp_appd' ); ?>
								<label class="switch"><input type="checkbox" name="edcgp_appd" value="1" <?php checked( $edcgp_appd, 1 ); ?>><span class="swisr"></span></label></td>	
						</tr>
					</table><br>

					<h2><?php echo __( 'Al actualizar información de una app', 'appyn' ); ?></h2>
					
					<table class="table-main">
						<tr>
							<td><h3><?php echo __( 'Deshabilitar campos', 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( 'Campos a deshabilitar al momento de actualizar la información de una aplicación.', 'appyn' ); ?>.</div>
							</td>
							<td><?php 
								$dca = get_option( 'appyn_dedcgp_descamp_actualizar', array() );
								?>
								<p><label><input type="checkbox" name="dedcgp_descamp_actualizar[]" value="app_title" <?php echo (is_array($dca) && in_array('app_title', $dca) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Título', 'appyn' ); ?></span></label></p>

								<p><label><input type="checkbox" name="dedcgp_descamp_actualizar[]" value="app_content" <?php echo (is_array($dca) && in_array('app_content', $dca) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Contenido', 'appyn' ); ?></span></label></p>

								<p><label><input type="checkbox" name="dedcgp_descamp_actualizar[]" value="app_download_links" <?php echo (is_array($dca) && in_array('app_download_links', $dca) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Enlaces de descarga', 'appyn' ); ?></span></label></p>
						</tr>
					</table><br>

					<h2><?php echo __( 'Google Drive', 'appyn' ); ?></h2>
					<?php
					$url = ( lang_wp() == "es" ) ? 'https://themespixel.net/api-google-drive-obtener-id-de-cliente-y-secreto-para-almacenamiento/' : 'https://themespixel.net/en/google-drive-api-get-client-id-and-secret-for-storage/';
					?>
					<table class="table-main">
						<tr>
							<td colspan="2"><?php echo __( 'Crea una API de Google Drive y coloca el ID de cliente y código secreto en los siguientes campos.', 'appyn' ); ?> <?php echo sprintf( __( 'Siga el %s para crear la API.', 'appyn' ), '<a href="'.$url.'" target="_blank">'. __( 'Tutorial', 'appyn' ). '</a>' ); ?><br>
							<?php echo __( 'Coloque los datos, guarde los cambios y luego haga clic al botón "Conectar a Google Drive".', 'appyn' ); ?></td>
						</tr>
						<tr>
							<td><h3><?php echo __( 'ID de cliente', 'appyn' ); ?></h3></td>
							<td><input type="text" name="gdrive_client_id" id="gdrive_client_id" value="<?php echo appyn_options( 'gdrive_client_id', true ); ?>" class="widefat"></td>
						</tr>
						<tr>
							<td><h3><?php echo __( 'Secreto del cliente', 'appyn' ); ?></h3></td>
							<td><input type="text" name="gdrive_client_secret" id="gdrive_client_secret" value="<?php echo appyn_options( 'gdrive_client_secret', true ); ?>" class="widefat"></td>
						</tr>
						<tr>
							<td><h3><?php echo __( 'Carpeta', 'appyn' ); ?><?php echo px_label_help( __('Coloca el nombre de una carpeta que se creará automáticamente y se subirán allí todos los archivos.', 'appyn' )); ?></h3></td>
							<td><input type="text" name="gdrive_folder" id="gdrive_folder" value="<?php echo appyn_options( 'gdrive_folder', true ); ?>" class="widefat"></td>
						</tr>
						<?php 
						$gdt = appyn_options( 'gdrive_token' );
						?>
						<tr>
							<td><?php 
								if( $gdt ) {
									echo '<a href="'.admin_url('admin.php?page=appyn_panel&action=new_gdrive_info#edcgp').'">'.__( 'Conectar nueva cuenta', 'appyn'). '</a>'.px_label_help( __('Haga clic aquí solo si ha añadido un nuevo ID de cliente y Secreto. Aparecerá nuevamente el botón de conectar que deberá pulsar.', 'appyn' ) );
								}
								?>
							</td>
							<td>
								<?php
								if( $gdt && appyn_options( 'gdrive_client_secret', true )  && appyn_options( 'gdrive_client_id', true ) ) {
									echo '<strong style="color:#50b250"><i class="fa fa-check"></i> '.__( 'Conectado a Google Drive', 'appyn').'</strong>';
								} else {
									echo '<a class="button" id="button_google_drive_connect" href="'. admin_url(). 'admin.php?page=appyn_panel&action=google_drive_connect">'.__( 'Conectar a Google Drive', 'appyn' ).'</a>';
								}
								?>	
							</td>
						</tr>
					</table><br>

					<h2><?php echo __( 'Dropbox', 'appyn' ); ?></h2>
					<?php
					$url = ( lang_wp() == "es" ) ? 'https://themespixel.net/crear-app-de-dropbox-para-almacenamiento-de-archivos/' : 'https://themespixel.net/en/create-dropbox-app-for-file-storage/';
					?>
					<table class="table-main">
						<tr>
 							<td colspan="2"><?php echo __( 'Crea una app en Dropbox y obtén el token de acceso.', 'appyn' ); ?> <?php echo sprintf( __( 'Siga el %s.', 'appyn' ), '<a href="'.$url.'" target="_blank">'.__( 'tutorial', 'appyn' ). '</a>' ); ?></td>
						</tr>
						<tr>
							<td><h3><?php echo __( 'Token de acceso', 'appyn' ); ?></h3></td>
							<td><input type="text" name="dropbox_access_token" id="dropbox_access_token" value="<?php echo appyn_options( 'dropbox_access_token', true ); ?>" class="widefat"></td>
						</tr>
					</table>
			</div>
            <div class="section" data-section="single">
				<h2><?php echo __( 'Single', 'appyn' ); ?></h2>
				<table class="table-main">
					<tr>
						<td><h3><?php echo __( 'Leer más', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __("Muestra todo el contenido del post o déjalo con el botón 'leer más'", 'appyn'); ?>.</div>
						</td>
						<td><?php $readmore_single = get_option( 'appyn_readmore_single' ); ?>
							<p><input type="radio" name="readmore_single" value="0" id="readmore_default" <?php checked( $readmore_single, 0, true); ?> checked> 
								<label for="readmore_default"><?php echo __( 'Leer más (defecto)', 'appyn' ); ?></label></p>
							<p><input type="radio" name="readmore_single" value="1" id="readmore_all" <?php checked( $readmore_single, 1, true); ?>> 
								<label for="readmore_all"><?php echo __( 'Mostrar todo', 'appyn' ); ?></label></p></td>
					</tr>
					<?php $download_links = get_option( 'appyn_download_links' ); ?>
					<tr>
						<td><h3><?php echo __( 'Enlaces de descarga', 'appyn' ); ?></h3>
							<div class="descr"><a href="<?php echo admin_url(); ?>admin.php?page=appyn_documentation#links-download"><?php echo __( '¿Cómo funciona esto?', 'appyn' ); ?></a></div>	
						</td>
						<td><p><label><input type="radio" name="download_links" value="0" <?php checked( $download_links, '', true); checked( $download_links, 0, true); ?>> <?php echo __( 'Normal', 'appyn' ); ?></label>
							</p>
                        	<p><label><input type="radio" name="download_links" value="1" <?php checked( $download_links, 1, true); ?>> <?php echo __( 'Página interna', 'appyn' ); ?></label>
							</p></td>
					</tr>
					<?php $redirect_timer = appyn_options( 'redirect_timer' ); ?>
					<tr>
						<td><h3><?php echo __( 'Temporizador de redirección', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Temporizador para la redirección del enlace de descarga', 'appyn' ); ?>.</div>	
						</td>
						<td>
							<p><label><input type="number" name="redirect_timer" min="0" max="999" value="<?php echo (isset($redirect_timer)) ? $redirect_timer : 5; ?>" class="input_number"> <?php echo __( 'segundos', 'appyn' ); ?></label></p>
							<p>
								<a href="https://demo.themespixel.net/appyn/lords-mobile-guerra-de-reinos-batalla-mmo-rpg/?download=redirect" target="_blank"><?php echo __( 'Ejemplo', 'appyn' ); ?> 1</a>
							</p>
						</td>
					</tr>
					<?php $download_timer = appyn_options( 'download_timer' ); ?>
					<tr>
						<td><h3><?php echo __( 'Temporizador de descarga', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Temporizador para mostrar los enlaces de descarga', 'appyn' ); ?>.</div>		
						</td>
						<td>
							<p><label><input type="number" name="download_timer" min="0" max="60" value="<?php echo (isset($download_timer)) ? $download_timer : 5; ?>" class="input_number"> <?php echo __( 'segundos', 'appyn' ); ?></label></p>
							<p>
								<a href="https://demo.themespixel.net/appyn/facebook/?download=links" target="_blank"><?php echo __( 'Ejemplo', 'appyn' ); ?> 1</a>
							</p>
						</td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Ordenar cajas', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Modifica el orden de las cajas a tu gusto', 'appyn' ); ?>.</div>	
						</td>
						<td><?php
							$oc_default = array( 
								'descripcion' => __( 'Descripción', 'appyn' ), 
								'ads_single_center' => __( 'ADS Single Center', 'appyn' ),
								'novedades' => __( 'Novedades', 'appyn' ), 
								'versiones' => __( 'Versiones', 'appyn' ), 
								'video' => __( 'Video', 'appyn' ), 
								'imagenes' => __( 'Imágenes', 'appyn' ), 
								'enlaces_descarga' => __( 'Enlaces de descarga', 'appyn' ), 
								'apps_relacionadas' => __( 'Apps relacionadas', 'appyn' ), 
								'apps_desarrollador' => __( 'Apps desarrollador', 'appyn' ),
								'cajas_personalizadas' => __( 'Cajas personalizadas', 'appyn' ), 
								'tags' => __( 'Etiquetas', 'appyn' ) 
							);
							$pcb = get_option( 'permanent_custom_boxes' );
							if( $pcb && is_array($pcb) ) {
								foreach( $pcb as $k => $p ) {
									$oc_default['permanent_custom_box_'.$k] = sprintf( __( 'Caja permanente %s', 'appyn' ), '#'.($k+1) );
								}
							}
							$oc = get_option( 'appyn_orden_cajas', $oc_default );
							$oc = array_merge($oc, $oc_default);
							?>
							<ul class="px-orden-cajas">
							<?php
							foreach( $oc as $k => $o ) {
								if( array_key_exists( $k, $oc_default ) ) {
							?>
								<li><input type="checkbox" name="orden_cajas[<?php echo $k; ?>]" value="<?php echo $oc[$k]; ?>" checked style="display:none;"><?php echo $oc[$k]; ?></li>
							<?php }
							} ?>
							</ul></td>
					</tr>
					
					<tr>
 						<td><h3><?php echo __( 'Cajas a quitar en la página de (descarga / redirección) interna ', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Marca las cajas que no quieres que aparezca en la página de descarga o redirección interna.', 'appyn' ); ?></div>
						</td>
						<td><?php 
							$cvn = get_option( 'appyn_pagina_interna_no_cajas', array() ); 
							?>
							<p><label><input type="checkbox" name="pagina_interna_no_cajas[]" value="descripcion" <?php echo (in_array('descripcion', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Descripción', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="pagina_interna_no_cajas[]" value="ads_single_center" <?php echo (in_array('ads_single_center', $cvn) ) ? 'checked' : ''; ?>> <span>ADS Single Center</span></label></p>

							<p><label><input type="checkbox" name="pagina_interna_no_cajas[]" value="novedades" <?php echo (in_array('novedades', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Novedades', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="pagina_interna_no_cajas[]" value="video" <?php echo (in_array('video', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Video', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="pagina_interna_no_cajas[]" value="imagenes" <?php echo (in_array('imagenes', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Imágenes', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="pagina_interna_no_cajas[]" value="enlaces_descarga" <?php echo (in_array('enlaces_descarga', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Enlaces de descarga', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="pagina_interna_no_cajas[]" value="apps_relacionadas" <?php echo (in_array('apps_relacionadas', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Apps relacionadas', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="pagina_interna_no_cajas[]" value="apps_desarrollador" <?php echo (in_array('apps_desarrollador', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Apps del desarrollador', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="pagina_interna_no_cajas[]" value="cajas_personalizadas" <?php echo (in_array('cajas_personalizadas', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Cajas personalizadas', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="pagina_interna_no_cajas[]" value="tags" <?php echo (in_array('tags', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Etiquetas', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="pagina_interna_no_cajas[]" value="comentarios" <?php echo (in_array('comentarios', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Comentarios', 'appyn' ); ?></span></label></p>

							<?php
							if( $pcb && is_array($pcb) ) {
								foreach( $pcb as $k => $p ) {
									echo '<p><label><input type="checkbox" name="pagina_interna_no_cajas[]" value="permanent_custom_box_'.$k.'" '. ((in_array('permanent_custom_box_'.$k, $cvn) ) ? 'checked' : '') .'> <span>'. sprintf( __( 'Caja permanente %s', 'appyn' ), '#'.($k+1) ) .'</span></label></p>';
								}
							}
							?>
						</td>
					</tr>
				</table>
					
			</div>
            <div class="section" data-section="historial_versiones">
				<h2><?php echo __( 'Historial de versiones', 'appyn' ); ?></h2>
				<table class="table-main">
					<tr>
						<td><h3><?php echo __( 'Cantidad en la entrada', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Escoge la cantidad de versiones que aparecerá en la caja de la entrada', 'appyn' ); ?>.</div>
						</td>
						<td><p><input type="number" name="versiones_cantidad_post" size="2" value="<?php $cvp = get_option( 'appyn_versiones_cantidad_post' ); echo ($cvp) ? $cvp : 5;  ?>" min="1" max="100" class="input_number" required> <?php echo __( 'Entradas', 'appyn' ); ?></p></td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Cajas a quitar de la entrada de versión antigua', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Marca las cajas que no quieres que aparezca en las entradas de historial de versiones.', 'appyn' ); ?></div>
						</td>
						<td><?php 
							$cvn = get_option( 'appyn_versiones_no_cajas', array() ); 
							?>
							<p><label><input type="checkbox" name="versiones_no_cajas[]" value="descripcion" <?php echo (in_array('descripcion', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Descripción', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="versiones_no_cajas[]" value="ads_single_center" <?php echo (in_array('ads_single_center', $cvn) ) ? 'checked' : ''; ?>> <span>ADS Single Center</span></label></p>

							<p><label><input type="checkbox" name="versiones_no_cajas[]" value="novedades" <?php echo (in_array('novedades', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Novedades', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="versiones_no_cajas[]" value="video" <?php echo (in_array('video', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Video', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="versiones_no_cajas[]" value="imagenes" <?php echo (in_array('imagenes', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Imágenes', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="versiones_no_cajas[]" value="enlaces_descarga" <?php echo (in_array('enlaces_descarga', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Enlaces de descarga', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="versiones_no_cajas[]" value="apps_relacionadas" <?php echo (in_array('apps_relacionadas', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Apps relacionadas', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="versiones_no_cajas[]" value="apps_desarrollador" <?php echo (in_array('apps_desarrollador', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Apps del desarrollador', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="versiones_no_cajas[]" value="cajas_personalizadas" <?php echo (in_array('cajas_personalizadas', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Cajas personalizadas', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="versiones_no_cajas[]" value="tags" <?php echo (in_array('tags', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Etiquetas', 'appyn' ); ?></span></label></p>

							<p><label><input type="checkbox" name="versiones_no_cajas[]" value="comentarios" <?php echo (in_array('comentarios', $cvn) ) ? 'checked' : ''; ?>> <span><?php echo __( 'Comentarios', 'appyn' ); ?></span></label></p>

							<?php
							if( $pcb && is_array($pcb) ) {
								foreach( $pcb as $k => $p ) {
									echo '<p><label><input type="checkbox" name="versiones_no_cajas[]" value="permanent_custom_box_'.$k.'" '. ((in_array('permanent_custom_box_'.$k, $cvn) ) ? 'checked' : '') .'> <span>'. sprintf( __( 'Caja permanente %s', 'appyn' ), '#'.($k+1) ) .'</span></label></p>';
								}
							}
							?>
							</td>
					</tr>
				</table>
			</div>
            <div class="section active" data-section="general">
				<h2><?php echo __( 'Opciones generales', 'appyn' ); ?></h2>
					<table class="table-main">

						<tr>

							<td>
								<h3><?php echo __( 'Logo', 'appyn' ); ?></h3>
									<div class="descr"><?php echo __( 'La imagen debe tener un límite de 60px de altura.', 'appyn' ); ?></div>
							</td>
							<td>
								<div class="regular-text-download">
									<input type="text" name="logo" id="logo" value="<?php $logo = get_option( 'appyn_logo' ); echo (!empty($logo)) ? $logo : get_bloginfo('template_url').'/images/logo.png'; ?>" class="regular-text upload">
									<input class="upload_image_button" type="button" value="&#xf093;"><br>
									<span class="imp"></span>
								</div>
							</td>
						</tr>

						<tr>
							<td><h3><?php echo __( 'Favicon', 'appyn' ); ?></h3></td>
							<td>
								<div class="regular-text-download">
									<input type="text" name="favicon" id="favicon" value="<?php $favicon = get_option( 'appyn_favicon' ); echo (!empty($favicon)) ? $favicon : get_bloginfo('template_url').'/images/favicon.ico'; ?>" class="regular-text upload">
									<input class="upload_image_button" type="button" value="&#xf093;">
								</div>
							</td>
						</tr>

						<tr>
							<td><h3><?php echo __( 'Redes sociales', 'appyn' ); ?></h3></td>
							<td><?php $color_botones_sociales = get_option( 'appyn_social_single_color' ); ?>
								<table class="sub-table">
									<tr>
										<td><?php echo __( 'Color', 'appyn' ); ?></td>
										<td>
											<label><input type="radio" name="social_single_color" value="default"<?php checked($color_botones_sociales, 'default'); ?>> <?php echo __( 'Gris (Por defecto)', 'appyn' ); ?> </label> &nbsp;
											<label><input type="radio" name="social_single_color" value="color"<?php checked($color_botones_sociales, 'color'); ?>> <?php echo __( 'Color', 'appyn' ); ?> </label>
										</td>
									</tr>
									<tr>
										<td>Facebook</td>
										<td><input type="text" name="social_facebook" value="<?php echo get_option( 'appyn_social_facebook' ); ?>" class="regular-text text2"></td>
									</tr>
									<tr>
										<td>Twitter</td>
										<td><input type="text" name="social_twitter" value="<?php echo get_option( 'appyn_social_twitter' ); ?>" class="regular-text text2"></td>
									</tr>
									<tr>
										<td>Instagram</td>
										<td><input type="text" name="social_instagram" value="<?php echo get_option( 'appyn_social_instagram' ); ?>" class="regular-text text2"></td>
									</tr>
									<tr>
										<td>Youtube</td>
										<td><input type="text" name="social_youtube" value="<?php echo get_option( 'appyn_social_youtube' ); ?>" class="regular-text text2"></td>
									</tr>
									<tr>
										<td>Pinterest</td>
										<td><input type="text" name="social_pinterest" value="<?php echo get_option( 'appyn_social_pinterest' ); ?>" class="regular-text text2"></td>
									</tr>
								</table>
								
								
							</td>
						</tr>


						<tr>
							<td><h3><?php echo __( 'Comentarios', 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( 'Puedes mostrar los comentarios de Wordpress y también los de Facebook.', 'appyn' ); ?>.</div></td>
							<td>
								<?php $comments = get_option( 'appyn_comments' ); ?>
								<p><input type="radio" name="comments" value="wp" id="comments_wp" <?php checked( $comments, 'wp', true); ?> checked> 
								<label for="comments_wp"><?php echo __( 'Comentarios de Wordpress', 'appyn' ); ?></label></p>

								<p><input type="radio" name="comments" value="fb" id="comments_fb" <?php checked( $comments, 'fb', true); ?>> 
								<label for="comments_fb"><?php echo __( 'Comentarios de Facebook', 'appyn' ); ?></label></p>

								<p><input type="radio" name="comments" value="wpfb" id="comments_wpfb" <?php checked( $comments, 'wpfb', true); ?>> 
								<label for="comments_wpfb"><?php echo __( 'Comentarios de Wordpress y Facebook', 'appyn' ); ?></label></p>

								<p><input type="radio" name="comments" value="disabled" id="comments_disabled" <?php checked( $comments, 'disabled', true); ?>> 
								<label for="comments_disabled"><?php echo __( 'Desactivar comentarios', 'appyn' ); ?></label></p>
							</td>
						</tr>

						<tr>
							<td><h3><?php echo __( 'Códigos header', 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( 'Coloca los códigos en el header, como: Google Analytics, Webmasters, Alexa, etc.', 'appyn' ); ?></div></td>
							<td><textarea name="header_codigos" class="widefat" rows="8"><?php echo stripslashes(get_option( 'appyn_header_codigos' )); ?></textarea></td>
						</tr>

						<tr>
							<td><h3><?php echo __( 'Códigos Recaptcha v3', 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( 'Para poder evitar que robots envíen los reportes automáticamente se recomienda usar recaptcha.', 'appyn' ); ?><br><a href="https://www.google.com/recaptcha/admin" target="_blank"><?php echo __( 'Obtener claves', 'appyn' ); ?></a></div></td>
                            <td><?php
								$recaptcha_secret = get_option( 'appyn_recaptcha_secret' );
								$recaptcha_site = get_option( 'appyn_recaptcha_site' );
								?>
								<table class="sub-table">
									<tr>
										<td><?php echo __( 'Clave del sitio', 'appyn' ); ?></td>
										<td><input type="text" name="recaptcha_site" value="<?php echo $recaptcha_site; ?>" class="regular-text"></td>
									</tr>
									<tr>
										<td><?php echo __( 'Clave secreta', 'appyn' ); ?></td>
										<td><input type="text" name="recaptcha_secret" value="<?php echo $recaptcha_secret; ?>" class="regular-text"></td>
									</tr>
								</table>
							</td>
						</tr>

						<tr>
							<td><h3><?php echo __( 'Lazy loading', 'appyn' ); ?> <?php echo px_label_help( __( 'Con esta función podrás retrasar la carga de imágenes. Esto hará que la web en general cargue más rápido debido a que las imágenes no cargarán inicialmente.', 'appyn' ) ); ?></h3>
								<div class="descr"><?php echo __( 'Retrasar carga de imágenes', 'appyn' ); ?></div></td>
							<td>
								<?php
								$appyn_lazy_loading = appyn_options( 'lazy_loading' );
								?>
								<p><label class="switch"><input type="checkbox" name="lazy_loading" value="1" <?php checked( $appyn_lazy_loading, 1 ); ?>><span class="swisr"></span></label></p>
							</td>
						</tr>
					
                		<tr>
							<td><h3><?php echo __( 'Apps de versiones anteriores', 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( 'Controla la aparición de apps de versiones anteriores en diferentes partes. Solo aparecerán las últimas versiones.', 'appyn' ); ?></div></td>
                        	<td>
								<?php
								$appyn_vmh = appyn_options( 'versiones_mostrar_inicio' );
								?>
								<table class="sub-table">
									<tr>
										<td style="width:165px"><?php echo __( 'Inicio', 'appyn' ); ?></td>
										<td><label class="switch"><input type="checkbox" name="versiones_mostrar_inicio" value="0" <?php checked( $appyn_vmh, 0 ); ?>><span class="swisr"></span></label></td>
									</tr>
									<?php
									$appyn_vmhc = appyn_options( 'versiones_mostrar_inicio_categorias' );
									?>
									<tr>
										<td><?php echo __( 'Categorías (Inicio)', 'appyn' ); ?></td>
										<td><label class="switch"><input type="checkbox" name="versiones_mostrar_inicio_categorias" value="0" <?php checked( $appyn_vmhc, 0 ); ?>><span class="swisr"></span></label></td>
									</tr>
									<?php
									$appyn_vmhamc = appyn_options( 'versiones_mostrar_inicio_apps_mas_calificadas' );
									?>
									<tr>
										<td><?php echo __( 'Apps más calificadas (Inicio)', 'appyn' ); ?></td>
										<td><label class="switch"><input type="checkbox" name="versiones_mostrar_inicio_apps_mas_calificadas" value="0" <?php checked( $appyn_vmhamc, 0 ); ?>><span class="swisr"></span></label></td>
									</tr>
									<?php
									$appyn_vmb = appyn_options( 'versiones_mostrar_buscador' );
									?>
									<tr>
										<td><?php echo __( 'Buscador', 'appyn' ); ?></td>
										<td><label class="switch"><input type="checkbox" name="versiones_mostrar_buscador" value="0" <?php checked( $appyn_vmb, 0 ); ?>><span class="swisr"></span></label></td>
									</tr>
									<?php
									$appyn_vmtd = appyn_options( 'versiones_mostrar_tax_desarrollador' );
									?>
									<tr>
										<td><?php echo __( 'Taxonomía desarrollador', 'appyn' ); ?></td>
										<td><label class="switch"><input type="checkbox" name="versiones_mostrar_tax_desarrollador" value="0" <?php checked( $appyn_vmtd, 0 ); ?>><span class="swisr"></span></label></td>
									</tr>
									<?php
									$appyn_vmc = appyn_options( 'versiones_mostrar_categorias' );
									?>
									<tr>
										<td><?php echo __( 'Categorías', 'appyn' ); ?></td>
										<td><label class="switch"><input type="checkbox" name="versiones_mostrar_categorias" value="0" <?php checked( $appyn_vmc, 0 ); ?>><span class="swisr"></span></label></td>
									</tr>
									<?php
									$appyn_vmt = appyn_options( 'versiones_mostrar_tags' );
									?>
									<tr>
										<td><?php echo __( 'Etiquetas', 'appyn' ); ?></td>
										<td><label class="switch"><input type="checkbox" name="versiones_mostrar_tags" value="0" <?php checked( $appyn_vmt, 0 ); ?>><span class="swisr"></span></label></td>
									</tr>
									<?php
									$appyn_vmw = appyn_options( 'versiones_mostrar_widgets' );
									?>
									<tr>
										<td><?php echo __( 'Widgets', 'appyn' ); ?></td>
										<td><label class="switch"><input type="checkbox" name="versiones_mostrar_widgets" value="0" <?php checked( $appyn_vmw, 0 ); ?>><span class="swisr"></span></label></td>
									</tr>
								</table>
							</td>
                    	</tr>
									
						<tr>
							<td><h3><?php echo __( 'Fecha de cada post', 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( 'Muestra la fecha en que fue creado el post en todas partes (Inicio, Widgets,etc.)', 'appyn' ); ?></div></td>
							<td>
								<?php
								$appyn_post_date = appyn_options( 'post_date' );
								?>
								<p><label class="switch"><input type="checkbox" name="post_date" value="1" <?php checked( $appyn_post_date, 1 ); ?>><span class="swisr"></span></label></p>

								<?php
								$appyn_post_date_type = appyn_options( 'post_date_type' );
								?>
								<p><?php echo __( 'Tipo de fecha', 'appyn' ); ?></p>
								
								<p><label><input type="radio" name="post_date_type" value="0" <?php checked( $appyn_post_date_type, "0" ); ?>> <?php echo __( 'Fecha de creación del post', 'appyn' ); ?></label></p>
								
								<p><label><input type="radio" name="post_date_type" value="1" <?php checked( $appyn_post_date_type, 1 ); ?>> <?php echo __( 'Fecha de última actualización de la app', 'appyn' ); ?></label></p>
							</td>
						</tr>
						<tr>
							<td><h3><?php echo __( 'Apps relacionadas', 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( 'Escoger la manera de mostrar apps relacionadas', 'appyn' ); ?>.</div></td>
							<td>
								<?php 
								$art = get_option( 'appyn_apps_related_type', array() ); 
								?>
								<p><input type="checkbox" name="apps_related_type[]" value="cat" id="apps_related_type_cat" <?php echo ( is_array($art) && in_array('cat', $art) || empty($art) ) ? 'checked' : ''; ?>> 
								<label for="apps_related_type_cat"><?php echo __( 'Por categoría(s) (Por defecto)', 'appyn' ); ?></label></p>

								<p><input type="checkbox" name="apps_related_type[]" value="tag" id="apps_related_type_tag" <?php echo ( is_array($art) && in_array('tag', $art) ) ? 'checked' : ''; ?>> 
								<label for="apps_related_type_tag"><?php echo __( 'Por etiqueta(s)', 'appyn' ); ?></label></p>

								<p><input type="checkbox" name="apps_related_type[]" value="title" id="apps_related_type_title" <?php echo ( is_array($art) && in_array('title', $art) ) ? 'checked' : ''; ?>> 
								<label for="apps_related_type_title"><?php echo __( 'Por título similar', 'appyn' ); ?></label></p>

								<p><input type="checkbox" name="apps_related_type[]" value="random" id="apps_related_type_random" <?php echo ( is_array($art) && in_array('random', $art) ) ? 'checked' : ''; ?>> 
								<label for="apps_related_type_random"><?php echo __( 'Al azar', 'appyn' ); ?></label></p>
							</td>
						</tr>
						<tr>
							<td><h3><?php echo __( 'Información para descargar los archivos', 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( 'Escribe los pasos que servirán de ayuda para el usuario.', 'appyn' ); ?>
								<p><a href="javascript:void(0);" class="autocomplete_info_download_apk_zip"><?php echo __( 'Autocompletar texto por defecto', 'appyn' ); ?></a></p>
								</div>
								<div id="default_apps_info_download_apk" style="display:none;"><?php echo get_option( 'appyn_apps_default_info_download_apk' ); ?></div>
								<div id="default_apps_info_download_zip" style="display:none;"><?php echo get_option( 'appyn_apps_default_info_download_zip' ); ?></div>
							</td>
							<td>
								<?php
								$aida = appyn_options( 'apps_info_download_apk', true );
								$aidz = appyn_options( 'apps_info_download_zip', true );
								?>
								<p>[Title] = <?php echo __( 'Título de la aplicación', 'appyn' ); ?></p>
								<p><b><?php echo __( 'Para archivos APK', 'appyn' ); ?></b></p>
								<?php wp_editor( $aida, 'apps_info_download_apk', array( 'media_buttons' => false, 'textarea_rows' => 8, 'quicktags' => false ) ); ?><br>

								<p><b><?php echo __( 'Para archivos ZIP', 'appyn' ); ?></b></p>
								<p><em><?php echo __( 'Algunos ZIP pueden obtener archivos APK y OBB necesarios para la instalación, por ello se debe recomendar usar una aplicación para instalar ese tipo de archivos, nosotros recomendamos "Split APKs Installer".', 'appyn' ); ?><a href="https://play.google.com/store/apps/details?id=com.aefyr.sai" target="_blank"><?php echo __( 'Ver aplicación', 'appyn' ); ?></a></em></p>
								<?php wp_editor( $aidz, 'apps_info_download_zip', array( 'media_buttons' => false, 'textarea_rows' => 8, 'quicktags' => false ) ); ?>
							</td>
						</tr>
						
						<tr>
							<td><h3><?php echo __( 'Encriptar enlaces', 'appyn' ); ?></h3>
								<div class="descr"><?php echo __( 'Con esta función podrás encriptar los enlaces de descarga.', 'appyn' ); ?></div></td>
							<td>
								<?php
								$appyn_encrypt_links = appyn_options( 'encrypt_links' );
								?>
								<p><label class="switch"><input type="checkbox" name="encrypt_links" value="1" <?php checked( $appyn_encrypt_links, 1 ); ?>><span class="swisr"></span></label></p>
							</td>
						</tr>
				</table>
            </div>
            <div class="section" data-section="blog">
				<h2>Blog</h2>
				
				<table class="table-main">
					<tr>
						<td><h3><?php echo __( 'Sección Blog en Home', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Coloque la cantidad de posts que debe aparecer en el home.', 'appyn' ); ?></div>							
						</td>
						<td><?php
							$blog_posts_home_limite = get_option( 'appyn_blog_posts_home_limite' );
							$blog_posts_home_limite = (empty($blog_posts_home_limite)) ? '4' : $blog_posts_home_limite;
							echo '<input type="number" name="blog_posts_home_limite" size="2" value="'.$blog_posts_home_limite.'" class="input_number" required> '.__( 'Entradas', 'appyn' );	
							?>
						</td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Blog Page', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Coloque la cantidad de posts que debe aparecer en la página blog', 'appyn' ); ?></div>
						</td>
						<td><?php
							$blog_posts_limite = get_option( 'appyn_blog_posts_limite' );
							$blog_posts_limite = (empty($blog_posts_limite)) ? '10' : $blog_posts_limite;
							echo '<input type="number" name="blog_posts_limite" size="2" value="'.$blog_posts_limite.'" class="input_number" required> '.__( 'Entradas', 'appyn' );					
							?>
						</td>
					</tr>
				</table>
            </div>
            
            
            
            <div class="section" data-section="footer">
				<h2>Footer</h2>
				
				<table class="table-main">
					<tr>
						<td><h3><?php echo __( 'Texto Footer', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Coloca cualquier texto en el footer. Permite HTML.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="footer_texto" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_footer_texto' )); ?></textarea></td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Códigos Footer', 'appyn' ); ?></h3></td>
						<td><textarea name="footer_codigos" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_footer_codigos' )); ?></textarea></td>
					</tr>
				</table>
    		</div>
            <div class="section" data-section="sidebar">
				<h2>Sidebar</h2>
				
				<table class="table-main">
					<tr>
						<td><h3><?php echo __( 'Activo', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Activar o desactivar el sidebar.', 'appyn' ); ?></div>
						</td>
						<td>
							<?php 
							$s = appyn_options( 'sidebar_active' ); ?>
							<p><label class="switch"><input type="checkbox" name="sidebar_active" value="0" <?php checked( $s, "0" ); ?>><span class="swisr"></span></label></p>
						</td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Posición del sidebar', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Escoja la ubicación del sidebar.', 'appyn' ); ?></div>
						</td>
						<td>
							<?php $sidebar_ubicacion = appyn_options( 'sidebar_ubicacion' ); ?>
							<p><label><input type="radio" name="sidebar_ubicacion" value="derecha" <?php checked( $sidebar_ubicacion, "derecha" ); ?> <?php checked( $sidebar_ubicacion, "0" ); ?>> <?php echo __( 'Derecha', 'appyn' ); ?></label></p>

							<p><label><input type="radio" name="sidebar_ubicacion" value="izquierda" <?php checked( $sidebar_ubicacion, "izquierda" ); ?>> <?php echo __( 'Izquierda', 'appyn' ); ?></label></p>
						</td>
					</tr>
				</table>
            </div>
            <div class="section" data-section="color">
				<h2><?php echo __( 'Colores', 'appyn' ); ?></h2>
				<table class="table-main">
					<tr>
						<td><h3><?php echo __( 'Estilo de color', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Escoja el tipo de tono que tendrá el tema.', 'appyn' ); ?></div>							
						</td>
						<td><?php $color_theme = appyn_options( 'color_theme' ); ?>					
							<p><label><input type="radio" name="color_theme" value="claro" <?php checked( $color_theme, "claro" ); ?> <?php checked( $color_theme, "0" ); ?>> <?php echo __( 'Claro', 'appyn' ); ?></label></p>
							
							<p><label><input type="radio" name="color_theme" value="oscuro" <?php checked( $color_theme, "oscuro" ); ?>> <?php echo __( 'Oscuro', 'appyn' ); ?></label></p>
						</td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Que el usuario escoja color', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Permitir que el usuario seleccione el color del tema.', 'appyn' ); ?></div>							
						</td>
						<td>
							<?php $c = appyn_options( 'color_theme_user_select' ); ?>
							<p><label class="switch"><input type="checkbox" name="color_theme_user_select" value="1" <?php checked( $c, 1 ); ?>><span class="swisr"></span></label></p>
						</td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Color principal', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Escoja el color principal del tema.', 'appyn' ); ?></div>				
						</td>
						<td><?php $color_theme_principal = get_option( 'appyn_color_theme_principal' );
						echo '<input name="color_theme_principal" class="colorpicker" value="#'.str_replace( '#', '', $color_theme_principal).'" data-default-color="#1bbc9b">'; ?></td>
					</tr>
				</table>
			</div>
			
			<div class="section" data-section="amp">
				<h2><?php echo __( 'AMP', 'appyn' ); ?></h2>
				<table class="table-main">
					<tr>
						<td><h3><?php echo __( 'AMP', 'appyn' ); ?></h3>
							<div class="descr">Accelerated Mobile Pages.<br>
							<a href="https://support.google.com/google-ads/answer/7496737" target="_blank"><?php echo __( 'Más información', 'appyn' ); ?></a></div></td>
						<td>
							<?php
							$appyn_amp = appyn_options( 'amp' );
							?>
							<label class="switch"><input type="checkbox" name="amp" value="1" <?php checked( $appyn_amp, 1 ); ?>><span class="swisr"></span></label>
						</td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Google Analytics', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Coloca el ID de Analytics', 'appyn' ); ?></div></td>
						<td><input type="text" name="analytics_amp" class="regular-text" value="<?php echo appyn_options( 'analytics_amp', true ); ?>" placeholder="UA-XXXXXXXX-XX"></td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Códigos header', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Coloca los códigos en el header (dentro de la etiqueta &lt;head&gt;&lt;/head&gt;)', 'appyn' ); ?></div></td>
						<td><textarea name="header_codigos_amp" class="widefat" rows="8"><?php echo stripslashes(get_option( 'appyn_header_codigos_amp' )); ?></textarea></td>
					</tr>
					<tr>
						<td><h3><?php echo __( 'Códigos body', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Coloca códigos debajo de la etiqueta &lt;body&gt;', 'appyn' ); ?></div></td>
						<td><textarea name="body_codigos_amp" class="widefat" rows="8"><?php echo stripslashes(get_option( 'appyn_body_codigos_amp' )); ?></textarea></td>
					</tr>
						<td><h3>ADS Header</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para la versión AMP', 'appyn' ); ?>.</div>
						</td>
						<td><textarea name="ads_header_amp" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_header_amp' )); ?></textarea></td>
					</tr>
					<tr>
						<td><h3>ADS Home, Page, Search, Categories, Tags, etc.</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para esas secciones en la versión AMP.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_home_amp" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_home_amp' )); ?></textarea></td>
					</tr>
					<tr>
						<td><h3>ADS Single Top</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para el single y page en la versión AMP.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_single_top_amp" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_single_top_amp' )); ?></textarea></td>
					</tr>
					
					<tr>
						<td><h3>ADS Single Center</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para el single y page en la parte central en la versión AMP.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_single_center_amp" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_single_center_amp' )); ?></textarea></td>
					</tr>
					
					<tr>
						<td><h3>ADS Download 1<br>
							<?php echo __( '(Página interna)', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para la parte superior de los enlaces de descarga en la página interna de la versión AMP.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_download_1_amp" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_download_1_amp' )); ?></textarea></td>
					</tr>
				</table>
			</div>

            <div class="section" data-section="ads">
				<h2><?php echo __( 'Anuncios', 'appyn' ); ?></h2>
				
				<table class="table-main">
					<tr>
						<td><h3><?php echo __( 'Texto encima de cada anuncio (Opcional)', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Coloca un texto encima de cada anuncio.', 'appyn' ); ?></div>
						</td>
						<td><input type="text" name="ads_text_above" class="regular-text" value="<?php echo stripslashes(get_option( 'appyn_ads_text_above' )); ?>"></td>
					</tr>
					<tr>
						<td><h3>ADS Header</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio debajo del header.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_header" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_header' )); ?></textarea></td>
					</tr>
					<tr>
						<td><h3>ADS Header [<?php echo __( 'Móvil', 'appyn' ); ?>]</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para la versión móvil', 'appyn' ); ?>.</div>
						</td>
						<td><textarea name="ads_header_movil" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_header_movil' )); ?></textarea></td>
					</tr>
						
					<tr>
						<td><h3>ADS Home, Page, Search, Categories, Tags, etc.</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para esas secciones.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_home" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_home' )); ?></textarea></td>
					</tr>
					
					<tr>
						<td><h3>ADS Home, Page, Search, Categories, Tags, etc. [<?php echo __( 'Móvil', 'appyn' ); ?>]</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para esas secciones en la versión móvil.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_home_movil" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_home_movil' )); ?></textarea></td>
					</tr>
					
					<tr>
						<td><h3>ADS Single Top</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para el single y page.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_single_top" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_single_top' )); ?></textarea></td>
					</tr>
					<tr>
						<td><h3>ADS Single Top [<?php echo __( 'Móvil', 'appyn' ); ?>]</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para el single y page en la versión móvil.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_single_top_movil" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_single_top_movil' )); ?></textarea></td>
					</tr>
					<tr>
						<td><h3>ADS Single Center</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para el single y page en la parte central.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_single_center" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_single_center' )); ?></textarea></td>
					</tr>
					<tr>
						<td><h3>ADS Single Center [<?php echo __( 'Móvil', 'appyn' ); ?>]</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para el single y page en la parte central en la versión móvil.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_single_center_movil" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_single_center_movil' )); ?></textarea></td>
					</tr>					

					<tr>
						<td><h3>ADS Download 1<br>
							<?php echo __( '(Página interna)', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para la parte superior de los enlaces de descarga en la página interna.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_download_1" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_download_1' )); ?></textarea></td>
					</tr>					

					<tr>
						<td><h3>ADS Download 2<br>
							<?php echo __( '(Página interna)', 'appyn' ); ?></h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para la parte inferior de los enlaces de descarga en la página interna.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_download_2" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_download_2' )); ?></textarea></td>
					</tr>				

					<tr>
						<td><h3>ADS Download 1<br>
							<?php echo __( '(Página interna)', 'appyn' ); ?> [<?php echo __( 'Móvil', 'appyn' ); ?>]</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para la parte superior de los enlaces de descarga en la página interna en la versión móvil.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_download_1_movil" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_download_1_movil' )); ?></textarea></td>
					</tr>					

					<tr>
						<td><h3>ADS Download 2<br>
							<?php echo __( '(Página interna)', 'appyn' ); ?> [<?php echo __( 'Móvil', 'appyn' ); ?>]</h3>
							<div class="descr"><?php echo __( 'Añade el código de anuncio para la parte inferior de los enlaces de descarga en la página interna en la versión móvil.', 'appyn' ); ?></div>
						</td>
						<td><textarea name="ads_download_2_movil" class="widefat" rows="7"><?php echo stripslashes(get_option( 'appyn_ads_download_2_movil' )); ?></textarea></td>
					</tr>
				</table>
            </div>
    	</form>
    </div>
</div>
<?php }

add_action( 'wp_ajax_px_panel_admin', 'px_panel_admin' ); 
add_action( 'wp_ajax_nopriv_px_panel_admin', 'px_panel_admin' );

function px_panel_admin() {
	global $wpdb;

	$nonce = sanitize_text_field( $_POST['nonce'] );

    if ( ! wp_verify_nonce( $nonce, 'admin_panel_nonce' ) ) die ( '✋');

	if( ! isset( $_POST['serializedData'] ) ) exit;

	parse_str($_POST['serializedData'], $output);

	$options = array(
		'logo',
		'favicon', 
		'titulo_principal',
		'descripcion_principal',
		'image_header1',
		'image_header2',
		'image_header3',
		'image_header4',
		'image_header5',
		'social_single_color', 
		'social_facebook', 
		'social_twitter',
		'social_instagram', 
		'social_youtube', 
		'social_pinterest',
		'mas_calificadas',
		'mas_calificadas_limite',
		'home_limite',
		'home_posts_orden',
		'categories_home',
		'categories_home_limite',
		'comments',
		'readmore_single',
		'header_codigos',
		'header_codigos_amp',
		'analytics_amp',
		'body_codigos_amp',
		'download_links',						
		'blog_posts_home_limite',
		'blog_posts_limite', 
		'ads_text_above',           
		'ads_header',
		'ads_header_movil',
		'ads_header_amp',
		'ads_home',
		'ads_home_movil',
		'ads_home_amp',
		'ads_single_top',
		'ads_single_top_movil',
		'ads_single_top_amp',
		'ads_single_center',
		'ads_single_center_movil',	
		'ads_single_center_amp',	
		'ads_download_1',				
		'ads_download_2',	
		'ads_download_1_movil',				
		'ads_download_2_movil',	
		'ads_download_1_amp',				
		'ads_download_2_amp',				
		'color_theme',
		'color_theme_user_select',
		'color_theme_principal',
		'sidebar_active',						
		'sidebar_ubicacion',			
		'footer_texto',
		'footer_codigos',
		'versiones_cantidad_post',
		'versiones_no_cajas',
		'orden_cajas',
		'recaptcha_secret',
		'recaptcha_site',
		'lazy_loading',
		'versiones_mostrar_inicio',
		'versiones_mostrar_inicio_categorias',
		'versiones_mostrar_inicio_apps_mas_calificadas',
		'versiones_mostrar_buscador',
		'versiones_mostrar_tax_desarrollador',
		'versiones_mostrar_categorias',
		'versiones_mostrar_tags',
		'versiones_mostrar_widgets',
		'edcgp_post_status',
		'edcgp_create_category',
		'edcgp_create_tax_dev',
		'edcgp_extracted_images',
		'edcgp_sapk',
		'edcgp_sapk_server',
		'edcgp_sapk_slug',
		'edcgp_rating',
		'edcgp_appd',
		'dedcgp_descamp_actualizar',
		'edcgp_roles',
		'download_timer',
		'redirect_timer',
		'pagina_interna_no_cajas',
		'amp',
		'post_date',
		'post_date_type',
		'apps_related_type',
		'apikey',
		'home_hidden_posts',
		'gdrive_client_id',
		'gdrive_client_secret',
		'gdrive_folder',
		'apps_info_download_apk',
		'apps_info_download_zip',
		'encrypt_links',
		'dropbox_access_token',
	);

	foreach( $options as $key => $opt ) {

		if( ! in_array( $opt, $options) ) continue;
			
		if( $opt == "versiones_no_cajas" && empty( $output["versiones_no_cajas"] ) ) {
			delete_option( 'appyn_versiones_no_cajas' );
			continue;
		}
		if( $opt == "pagina_interna_no_cajas" && empty( $output["pagina_interna_no_cajas"] ) ) {
			delete_option( 'appyn_pagina_interna_no_cajas' );
			continue;
		}
		if( $opt == "versiones_mostrar_inicio" ||
			$opt == "versiones_mostrar_inicio_categorias" ||
			$opt == "versiones_mostrar_inicio_apps_mas_calificadas" ||
			$opt == "versiones_mostrar_tax_desarrollador" ||
			$opt == "versiones_mostrar_buscador" ||
			$opt == "versiones_mostrar_categorias" ||
			$opt == "versiones_mostrar_tags" ||
			$opt == "versiones_mostrar_widgets" || 
			$opt == "edcgp_create_tax_dev" ||
			$opt == "edcgp_sapk" ||
			$opt == "edcgp_create_category" ||
			$opt == "sidebar_active"
			) {
			if( ! isset( $output[$opt] ) ) {
				update_option( 'appyn_'.$opt, 1 );
			} else {
				update_option( 'appyn_'.$opt, stripslashes_deep($output[$opt]) );
			}
			continue;
		}
		update_option( 'appyn_'.$opt, @stripslashes_deep($output[$opt]) );

	}
	die();
}