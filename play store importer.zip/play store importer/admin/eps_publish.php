<?php 
header('Content-Type: text/html; charset=utf-8');
define('WP_USE_THEMES', false);
global $wpdb;
require('../../../../wp-load.php');

if( !isset($_POST['url_app']) || !isset($_POST['nonce']) ) exit;

$nonce = sanitize_text_field( $_POST['nonce'] );

if ( ! wp_verify_nonce( $nonce, 'importgp_nonce' ) ) die ( '✋');

if( empty(appyn_options( 'apikey' )) ) {
	$output['info'] = __( 'Error: La API Key es inválida.', 'appyn' ).' <a href="https://themespixel.net/docs/appyn/api-key/" target="_blank">'.__( 'Más información', 'appyn' ).'</a>';
	echo json_encode($output);
	exit;
}

$url_app = $_POST['url_app'];
$output = array();
if( !get_http_response_code( $url_app ) ) {
	$output['info'] = __( 'Error: Al parecer la URL no existe. Verifique nuevamente.', 'appyn' );
	echo json_encode($output);
	exit;
}

if( appyn_options('edcgp_appd') != 1 ) {
	$results = $wpdb->get_results("SELECT SQL_CALC_FOUND_ROWS  {$wpdb->prefix}posts.ID FROM {$wpdb->prefix}posts  INNER JOIN {$wpdb->prefix}postmeta ON ( {$wpdb->prefix}posts.ID = {$wpdb->prefix}postmeta.post_id ) WHERE 1=1  AND (( {$wpdb->prefix}postmeta.meta_key = 'datos_informacion' AND {$wpdb->prefix}postmeta.meta_value LIKE '%:\"{$url_app}\";%' )) AND {$wpdb->prefix}posts.post_type = 'post' AND (({$wpdb->prefix}posts.post_status = 'publish' OR {$wpdb->prefix}posts.post_status = 'future' OR {$wpdb->prefix}posts.post_status = 'draft')) GROUP BY {$wpdb->prefix}posts.ID ORDER BY {$wpdb->posts}.post_date DESC LIMIT 0, 10");
	
	if( count($results) != 0 )  {
        $output['info'] = sprintf(__( 'Error: La aplicación que desea importar ya existe. %s', 'appyn' ), '<a href="'.get_edit_post_link($results[0]->ID).'" target="_blank">'.__( 'Ver entrada', 'appyn' ).'</a>');
        echo json_encode($output);
        exit;
	}
}

$edcgp_sapk = appyn_options( 'edcgp_sapk', true );

$data = array(
	'apikey' 	=> file_get_contents('https://hive-store.com/Keyzone/appyn/api.txt'),
	'website'	=> file_get_contents('https://hive-store.com/Keyzone/appyn/key.txt'),
	'app'		=> trim($url_app)
);

if( !$edcgp_sapk ) {
	$data['apk'] = "true";
}

$url = "https://api.themespixel.net/?".http_build_query($data);

$bot = go_curl($url);

$bot = json_decode($bot, true);

if( isset($bot['error_web']) ) {
	$output['info'] = __( 'Error: Este dominio no está habilitado.', 'appyn' ).' <a href="https://themespixel.net/docs/appyn/api-key/" target="_blank">'.__( 'Más información', 'appyn' ).'</a>';
	echo json_encode($output);
	exit;
}

if( isset($bot['error_apikey']) ) {
	$output['info'] = __( 'Error: La API Key es inválida.', 'appyn' ).' <a href="https://themespixel.net/docs/appyn/api-key/" target="_blank">'.__( 'Más información', 'appyn' ).'</a>';
	echo json_encode($output);
	exit;
}

$bot = $bot['app'];

$datos['nombre']  				= $bot['title'];
$datos['contenido']  			= $bot['content'];
$datos['descripcion']  			= $bot['description'];
$datos['fecha_actualizacion']  	= $bot['date'];
$datos['last_update'] 		 	= $bot['last_update'];
$datos['version']  				= $bot['version'];
$datos['requerimientos']  		= $bot['requires'];
$datos['novedades']  			= $bot['whats_new'];
$datos['imagecover']  			= $bot['icon'];
$datos['video']  				= $bot['video'];
$datos['tamano']  				= $bot['size'];
$datos['categoria']  			= $bot['cat'];
$datos['desarrollador']  		= $bot['developer'];
$datos['pago']  				= $bot['is_pay'];

$edcgp_post_status 			= appyn_options( 'edcgp_post_status' );
$edcgp_create_category 		= appyn_options( 'edcgp_create_category' );
$edcgp_create_tax_dev 		= appyn_options( 'edcgp_create_tax_dev' );
$edcgp_extracted_images 	= appyn_options( 'edcgp_extracted_images' ) ? appyn_options( 'edcgp_extracted_images' ) : 5;

$n = 0;
foreach($bot['screenshots'] as $screenshot) { 
	if( $n < $edcgp_extracted_images ) {
		$datos['imagenes'][$n] = $screenshot;
	}
	$n++;
}	

if( $edcgp_create_category != 1 ) {
	// Agregar categoría
	require_once( ABSPATH . '/wp-admin/includes/taxonomy.php');
		$cat_defaults = array(
			'cat_ID' => 0,
			'cat_name' => $datos['categoria'],
			'taxonomy' => 'category');
		wp_insert_category( $cat_defaults );
		$term_id = term_exists($datos['categoria'], 'category');
}
	

$my_post = array(
	'post_title'    => wp_strip_all_tags( $datos['nombre'] ),
	'post_content'  => $datos['contenido'],
	'post_author'   => get_current_user_id(),
);
if( $edcgp_post_status == 1 ) {
	$my_post['post_status'] = 'publish';
} else {
	$my_post['post_status'] = 'draft';
}

if( $edcgp_create_category != 1 ) {
	$my_post['post_category'] = array($term_id);
}
$post_id = wp_insert_post( $my_post );

if( $post_id ) {
	$output['post_id'] = $post_id;
	$info = __( 'Información importada.', 'appyn' )."\n";
	$output['info_text'] = '<i class="fa fa-check"></i> '.sprintf(__( 'Entrada "%s" creada.', 'appyn' ), $datos['nombre']).' <a href="'.get_edit_post_link($post_id).'" target="_blank">'.__( 'Ver post', 'appyn' ).'</a>';
}
if( $edcgp_create_category != 1 ) {
	// Agregar categoría
	wp_set_post_terms($post_id, $term_id, 'category');
}

if( $edcgp_create_tax_dev != 1 ) {
	// Agregar taxonomía
	$post_datos_informacion = str_replace(',', '', $datos['desarrollador']);
	wp_insert_term( $post_datos_informacion, 'dev' );
	$term_id = term_exists( $post_datos_informacion, 'dev' );
	wp_set_post_terms( $post_id, $post_datos_informacion, 'dev' );
}
px_upload_image();


$datos_informacion = array(
	'descripcion' 			=> $datos['descripcion'],
	'version' 				=> $datos['version'],
	'tamano' 				=> $datos['tamano'],
	'fecha_actualizacion' 	=> $datos['fecha_actualizacion'],
	'last_update'		 	=> $datos['last_update'],
	'requerimientos' 		=> $datos['requerimientos'],
	'novedades' 			=> $datos['novedades'],
	'consiguelo' 			=> $url_app,
);
if( $bot['is_pay'] ) {
	$datos_informacion['offer']['price'] = 'pago';
}

update_post_meta($post_id, "datos_informacion", $datos_informacion);	
update_post_meta($post_id, "datos_video", array('id' => $datos['video']));
update_post_meta($post_id, "datos_imagenes", $datos['imagenes']);

if( get_option( 'appyn_edcgp_rating' ) ) {
	
	$rating = $bot['rating'];

	update_post_meta($post_id, "new_rating_users", ((isset($rating['users'])) ? $rating['users'] : ''));
	update_post_meta($post_id, "new_rating_count", ((isset($rating['total'])) ? $rating['total'] : ''));
	update_post_meta($post_id, 'new_rating_average', ((isset($rating['average'])) ? $rating['average'] : ''));
}

if( !$edcgp_sapk ) {
	if( $bot['apk'] ) {

		$re = '/(?<=[?&]id=)[^&]+/m';
		$str = $url_app;
		preg_match_all($re, $str, $matches, PREG_SET_ORDER, 0);
		$idps = $matches[0][0];

		$output['apk_info'] = array(
			'post_id' => $post_id,
			'idps' 	  => $idps,
			'date' 	  => $bot['last_update'],
		);

		$output['apk_info']['url'] = $bot['apk'];

		$tsr = px_option_selected_upload(); 

		if( px_check_apk_obb($bot['apk']) ) {
			$output['apk_info']['text']['step1'] = '<i class="fa fa-file" aria-hidden="true"></i> '. __( 'Se encontró un archivo APK y OBB', 'appyn' );
			$output['apk_info']['text']['step2'] = '<i class="fa fa-download" aria-hidden="true"></i> '. __( 'Descargando archivo...', 'appyn' ).' <span class="percentage">'. __( 'En proceso...', 'appyn' ).'</span>';
			$output['apk_info']['text']['step3'] = '<i class="fa fa-spinner" aria-hidden="true"></i> '. sprintf( __( 'Subiendo a %s en ZIP', 'appyn' ), $tsr);
			
		} else {
			$output['apk_info']['text']['step1'] = '<i class="fa fa-file" aria-hidden="true"></i> '. __( 'Se encontró un archivo APK', 'appyn' );
			if( array_key_exists('zip', $bot['apk']) ) {
				$output['apk_info']['text']['step1'] = '<i class="fa fa-file" aria-hidden="true"></i> '. __( 'Se encontró un archivo ZIP', 'appyn' );
			}
			$output['apk_info']['text']['step2'] = '<i class="fa fa-download" aria-hidden="true"></i> '. __( 'Descargando archivo...', 'appyn' ).' <span class="percentage">'. __( 'En proceso...', 'appyn' ).'</span>';
			$output['apk_info']['text']['step3'] = '<i class="fa fa-spinner" aria-hidden="true"></i> '. sprintf( __( 'Subiendo a %s', 'appyn' ), $tsr);
		}
	}
}
	
$output['info'] = $info;
echo json_encode($output);